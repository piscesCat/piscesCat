<?php
$captiveHosts = [
    'msftconnecttest.com','msftncsi.com','dns.msftncsi.com','ipv6.msftconnecttest.com',
    'captive.apple.com','apple.com','gsp1.apple.com','airport.us','akamaitechnologies.com','akamaiedge.net','apple.com.edgekey.net',
    'connectivitycheck.gstatic.com','clients3.google.com','clients4.google.com','gstatic.com',
    'nmcheck.gnome.org','networkcheck.kde.org',
    'spectrum.s3.amazonaws.com',
    'detectportal.firefox.com','detectportal.brave-http-only.com',
    'cloudflareportal.com','cloudflarecp.com','cloudflareok.com',
    'connectivity.cloudflareclient.com','connectivity-check.warp-svc',
];

$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
$uri  = strtolower($_SERVER['REQUEST_URI'] ?? '');
$host = 'captive.portal';
foreach ($captiveHosts as $h) {
    if (stripos($host, $h) !== false) {
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Location: http://captive.portal', true, 302);
        exit;
    }
}

if ($host === 'captive.portal') {
	if ($uri === '/login-process') {
		include('login-process.php');
		exit;
	}
	
	header('Content-Type: text/html');
	$content = file_get_contents('index.html');
	$content = str_replace('[USER_MAC]', getenv('USER_MAC'), $content);
	$content = str_replace('[USER_IP]', getenv('USER_IP'), $content);
	echo $content;
    exit;
}
