// Main JavaScript file
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip);
    });

    // Handle story search with debounce
    const searchInput = document.querySelector('#story-search');
    if (searchInput) {
        let timeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                searchStories(this.value);
            }, 500);
        });
    }

    // Initialize reading settings
    initializeReadingSettings();
});

// Story search function
function searchStories(query) {
    fetch(`/stories/search?q=${encodeURIComponent(query)}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const resultsContainer = document.querySelector('#search-results');
        if (resultsContainer) {
            resultsContainer.innerHTML = data.html;
        }
    });
}

// Reading settings initialization
function initializeReadingSettings() {
    const settings = JSON.parse(localStorage.getItem('readingSettings')) || {
        fontSize: 18,
        theme: 'light'
    };

    // Apply saved settings
    const content = document.querySelector('.chapter-content');
    if (content) {
        content.style.fontSize = `${settings.fontSize}px`;
        if (settings.theme === 'dark') {
            document.body.classList.add('dark');
        }
    }

    // Font size controls
    const increaseFontBtn = document.querySelector('#increase-font');
    const decreaseFontBtn = document.querySelector('#decrease-font');
    
    if (increaseFontBtn && decreaseFontBtn) {
        increaseFontBtn.addEventListener('click', () => {
            if (settings.fontSize < 32) {
                settings.fontSize += 2;
                updateReadingSettings(settings);
            }
        });

        decreaseFontBtn.addEventListener('click', () => {
            if (settings.fontSize > 12) {
                settings.fontSize -= 2;
                updateReadingSettings(settings);
            }
        });
    }

    // Theme toggle
    const themeToggle = document.querySelector('#theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            settings.theme = settings.theme === 'light' ? 'dark' : 'light';
            document.body.classList.toggle('dark');
            updateReadingSettings(settings);
        });
    }
}

// Update reading settings
function updateReadingSettings(settings) {
    localStorage.setItem('readingSettings', JSON.stringify(settings));
    const content = document.querySelector('.chapter-content');
    if (content) {
        content.style.fontSize = `${settings.fontSize}px`;
    }
}

// Handle bookmark toggle
function toggleBookmark(storyId) {
    fetch(`/story/bookmark/${storyId}`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const bookmarkBtn = document.querySelector(`#bookmark-${storyId}`);
        if (bookmarkBtn) {
            bookmarkBtn.classList.toggle('active');
        }
    });
}

// Admin panel functions
function confirmDelete(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Handle image preview
function previewImage(input, previewId) {
    const preview = document.getElementById(previewId);
    const file = input.files[0];
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        reader.readAsDataURL(file);
    }
}