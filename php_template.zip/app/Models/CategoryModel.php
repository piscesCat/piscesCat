<?php
namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table = 'categories';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = ['name', 'slug', 'description', 'parent_id'];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'name' => 'required|min_length[2]|max_length[50]',
        'slug' => 'required|alpha_dash|min_length[2]|max_length[50]|is_unique[categories.slug,id,{id}]',
        'description' => 'permit_empty|max_length[255]'
    ];

    protected $validationMessages = [
        'name' => [
            'required' => 'Tên thể loại là bắt buộc',
            'min_length' => 'Tên thể loại phải có ít nhất 2 ký tự'
        ],
        'slug' => [
            'required' => 'Đường dẫn thể loại là bắt buộc',
            'is_unique' => 'Đường dẫn này đã tồn tại'
        ]
    ];

    public function getCategories($withCount = true)
    {
        $builder = $this->select('categories.*');
        
        if ($withCount) {
            $builder->select('(SELECT COUNT(*) FROM story_categories 
                             WHERE category_id = categories.id) as story_count');
        }

        return $builder->orderBy('name', 'ASC')->findAll();
    }

    public function getStoriesByCategory($slug, $limit = 12, $offset = 0)
    {
        return $this->db->table('stories')
                        ->select('stories.*, users.username as author_name, categories.name as category_name')
                        ->join('story_categories', 'stories.id = story_categories.story_id')
                        ->join('categories', 'categories.id = story_categories.category_id')
                        ->join('users', 'users.id = stories.author_id')
                        ->where('categories.slug', $slug)
                        ->where('stories.status', 'published')
                        ->orderBy('stories.created_at', 'DESC')
                        ->limit($limit, $offset)
                        ->get()
                        ->getResultArray();
    }

    public function getCategoryBySlug($slug)
    {
        return $this->where('slug', $slug)->first();
    }

    public function addStoryToCategory($storyId, $categoryId)
    {
        return $this->db->table('story_categories')
                        ->insert([
                            'story_id' => $storyId,
                            'category_id' => $categoryId
                        ]);
    }

    public function removeStoryFromCategory($storyId, $categoryId)
    {
        return $this->db->table('story_categories')
                        ->where('story_id', $storyId)
                        ->where('category_id', $categoryId)
                        ->delete();
    }
}