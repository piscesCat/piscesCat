<?php
// app/Helpers/twig_helper.php
if (!function_exists('twig_function')) {
    function twig_function($name, $callback)
    {
        $twig = service('twig');
        $function = new \Twig\TwigFunction($name, $callback);
        $twig->addFunction($function);
    }
}

if (!function_exists('twig_filter')) {
    function twig_filter($name, $callback)
    {
        $twig = service('twig');
        $filter = new \Twig\TwigFilter($name, $callback);
        $twig->addFilter($filter);
    }
}

// Add custom Twig functions
twig_function('base_url', function($uri = '') {
    return base_url($uri);
});

twig_function('site_url', function($uri = '') {
    return site_url($uri);
});

twig_function('current_url', function() {
    return current_url();
});

twig_function('form_open', function($action = '', $attributes = [], $hidden = []) {
    return form_open($action, $attributes, $hidden);
});

twig_function('form_close', function() {
    return form_close();
});

twig_function('csrf_field', function() {
    return csrf_field();
});

// Add custom Twig filters
twig_filter('limit_text', function($text, $limit = 100) {
    if (strlen($text) > $limit) {
        return substr($text, 0, $limit) . '...';
    }
    return $text;
});

twig_filter('time_ago', function($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'vừa xong';
    } elseif ($diff < 3600) {
        return floor($diff / 60) . ' phút trước';
    } elseif ($diff < 86400) {
        return floor($diff / 3600) . ' giờ trước';
    } elseif ($diff < 2592000) {
        return floor($diff / 86400) . ' ngày trước';
    } else {
        return date('d/m/Y', $time);
    }
});