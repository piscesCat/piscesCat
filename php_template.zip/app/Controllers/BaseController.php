<?php
// app/Controllers/BaseController.php
namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class BaseController extends Controller
{
    protected $request;
    protected $helpers = ['url', 'form', 'twig'];
    protected $twig;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        // Initialize Twig
        $loader = new FilesystemLoader(APPPATH . 'Views');
        $this->twig = new Environment($loader, [
            'cache' => WRITEPATH . 'cache/twig',
            'auto_reload' => true,
            'debug' => ENVIRONMENT === 'development',
        ]);

        // Add Global Variables
        $this->twig->addGlobal('session', session());
        $this->twig->addGlobal('current_user', session()->get('user'));
        $this->twig->addGlobal('base_url', base_url());
    }

    protected function render(string $template, array $data = [])
    {
        return $this->twig->render($template, $data);
    }
}