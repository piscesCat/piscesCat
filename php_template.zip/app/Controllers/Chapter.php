<?php
namespace App\Controllers;

use App\Models\ChapterModel;
use App\Models\StoryModel;

class Chapter extends BaseController
{
    protected $chapterModel;
    protected $storyModel;

    public function __construct()
    {
        $this->chapterModel = new ChapterModel();
        $this->storyModel = new StoryModel();
    }

    public function view($storySlug, $chapterNumber)
    {
        $story = $this->storyModel->where('slug', $storySlug)
            ->where('status', 'published')
            ->first();

        if (!$story) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $chapter = $this->chapterModel->getChapter($story['id'], $chapterNumber);

        if (!$chapter) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Increment views
        $this->chapterModel->incrementViews($chapter['id']);

        // Get next and previous chapters
        $nextChapter = $this->chapterModel->getNextChapter($story['id'], $chapterNumber);
        $prevChapter = $this->chapterModel->getPreviousChapter($story['id'], $chapterNumber);

        // Save reading progress if user is logged in
        if (session()->get('isLoggedIn')) {
            $this->saveReadingProgress($story['id'], $chapter['id']);
        }

        return $this->render('chapter/view.twig', [
            'story' => $story,
            'chapter' => $chapter,
            'nextChapter' => $nextChapter,
            'prevChapter' => $prevChapter
        ]);
    }

    protected function saveReadingProgress($storyId, $chapterId)
    {
        $userId = session()->get('user')['id'];
        
        $db = \Config\Database::connect();
        $db->table('reading_progress')->replace([
            'user_id' => $userId,
            'story_id' => $storyId,
            'chapter_id' => $chapterId,
            'last_read' => date('Y-m-d H:i:s')
        ]);
    }

    public function list($storySlug)
    {
        $story = $this->storyModel->where('slug', $storySlug)
            ->where('status', 'published')
            ->first();

        if (!$story) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $chapters = $this->chapterModel->getChaptersByStory($story['id']);

        return $this->render('chapter/list.twig', [
            'story' => $story,
            'chapters' => $chapters
        ]);
    }
}