<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\StoryModel;
use App\Models\CategoryModel;

class StoryManager extends BaseController
{
    protected $storyModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->categoryModel = new CategoryModel();

        // Check if user is admin
        if (!$this->isAdmin()) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }
    }

    public function index()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $stories = $this->storyModel->select('stories.*, users.username as author_name')
            ->join('users', 'users.id = stories.author_id')
            ->findAll($limit, $offset);

        $total = $this->storyModel->countAllResults();

        return $this->render('admin/story/index.twig', [
            'stories' => $stories,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ]
        ]);
    }

    public function create()
    {
        $categories = $this->categoryModel->findAll();

        return $this->render('admin/story/create.twig', [
            'categories' => $categories
        ]);
    }

    public function store()
    {
        $rules = [
            'title' => 'required|min_length[3]|max_length[200]',
            'description' => 'required|min_length[10]',
            'categories' => 'required|array|min_length[1]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $coverImage = $this->request->getFile('cover_image');
        $coverPath = '';
        
        if ($coverImage && $coverImage->isValid()) {
            $coverPath = $coverImage->store('covers/');
        }

        $storyId = $this->storyModel->insert([
            'title' => $this->request->getPost('title'),
            'slug' => url_title($this->request->getPost('title'), '-', true),
            'description' => $this->request->getPost('description'),
            'cover_image' => $coverPath,
            'author_id' => session()->get('user')['id'],
            'status' => $this->request->getPost('status') ?? 'draft'
        ]);

        // Add categories
        foreach ($this->request->getPost('categories') as $categoryId) {
            $this->categoryModel->addStoryToCategory($storyId, $categoryId);
        }

        return redirect()->to('/admin/stories')
            ->with('success', 'Truyện đã được tạo thành công');
    }

    public function edit($id)
    {
        $story = $this->storyModel->find($id);
        if (!$story) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $categories = $this->categoryModel->findAll();
        $storyCategories = $this->categoryModel->getStoriesCategories($id);

        return $this->render('admin/story/edit.twig', [
            'story' => $story,
            'categories' => $categories,
            'storyCategories' => $storyCategories
        ]);
    }

    public function update($id)
    {
        // Similar validation and update logic as store()
    }

    public function delete($id)
    {
        $this->storyModel->delete($id);
        return redirect()->to('/admin/stories')
            ->with('success', 'Truyện đã được xóa thành công');
    }

    protected function isAdmin()
    {
        return session()->get('user')['role'] === 'admin';
    }
}