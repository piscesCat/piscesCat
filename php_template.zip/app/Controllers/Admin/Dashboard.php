<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
    public function __construct()
    {
        // Check if user is admin
        if (!$this->isAdmin()) {
            return redirect()->to('/')->with('error', 'Unauthorized access');
        }
    }

    public function index()
    {
        $db = \Config\Database::connect();
        
        // Get statistics
        $stats = [
            'total_stories' => $db->table('stories')->countAllResults(),
            'total_chapters' => $db->table('chapters')->countAllResults(),
            'total_users' => $db->table('users')->countAllResults(),
            'total_views' => $db->table('stories')->selectSum('views')->get()->getRow()->views
        ];

        // Get recent activities
        $activities = $db->table('activities')
            ->select('activities.*, users.username')
            ->join('users', 'users.id = activities.user_id')
            ->orderBy('created_at', 'DESC')
            ->limit(10)
            ->get()
            ->getResultArray();

        // Get top stories
        $topStories = $db->table('stories')
            ->select('stories.*, users.username as author_name')
            ->join('users', 'users.id = stories.author_id')
            ->orderBy('views', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();

        return $this->render('admin/dashboard.twig', [
            'stats' => $stats,
            'activities' => $activities,
            'topStories' => $topStories
        ]);
    }

    protected function isAdmin()
    {
        return session()->get('user')['role'] === 'admin';
    }

    public function systemInfo()
    {
        $info = [
            'php_version' => phpversion(),
            'codeigniter_version' => \CodeIgniter\CodeIgniter::CI_VERSION,
            'server_software' => $_SERVER['SERVER_SOFTWARE'],
            'database_driver' => \Config\Database::connect()->DBDriver,
            'upload_max_size' => ini_get('upload_max_filesize'),
            'memory_limit' => ini_get('memory_limit')
        ];

        return $this->render('admin/system_info.twig', [
            'info' => $info
        ]);
    }
}