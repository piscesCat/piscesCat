<?php
// app/Controllers/Home.php
namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $storyModel = model('StoryModel');
        
        $data = [
            'featured_stories' => $storyModel->getFeatured(5),
            'latest_stories' => $storyModel->getLatest(12),
            'popular_stories' => $storyModel->getPopular(8),
            'categories' => model('CategoryModel')->findAll()
        ];

        return $this->render('home.twig', $data);
    }
}