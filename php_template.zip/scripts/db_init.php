<?php
// scripts/db_init.php

require_once __DIR__ . '/../vendor/autoload.php';

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Database connection parameters
$host = $_ENV['DB_HOSTNAME'] ?? 'localhost';
$port = $_ENV['DB_PORT'] ?? 5432;
$dbname = $_ENV['DB_DATABASE'] ?? 'story_website';
$user = $_ENV['DB_USERNAME'] ?? 'postgres';
$password = $_ENV['DB_PASSWORD'] ?? 'postgres';

try {
    // Create database if it doesn't exist
    $pdo = new PDO("pgsql:host=$host;port=$port", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Check if database exists
    $stmt = $pdo->query("SELECT 1 FROM pg_database WHERE datname = '$dbname'");
    if (!$stmt->fetch()) {
        $pdo->exec("CREATE DATABASE $dbname");
        echo "Database '$dbname' created successfully.\n";
    }
    
    // Connect to the new database
    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Read and execute schema.sql
    $schema = file_get_contents(__DIR__ . '/../database/schema.sql');
    $pdo->exec($schema);
    echo "Schema created successfully.\n";
    
    // Basic validation
    $tables = [
        'users', 'stories', 'categories', 'chapters', 'bookmarks',
        'reading_progress', 'ratings', 'comments', 'activities'
    ];
    
    foreach ($tables as $table) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
        $count = $stmt->fetchColumn();
        echo "Table '$table' exists with $count records.\n";
    }
    
    // Verify admin user
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
    $adminCount = $stmt->fetchColumn();
    if ($adminCount > 0) {
        echo "Admin user exists.\n";
    } else {
        echo "Warning: No admin user found.\n";
    }
    
    // Verify categories
    $stmt = $pdo->query("SELECT COUNT(*) FROM categories");
    $categoryCount = $stmt->fetchColumn();
    if ($categoryCount > 0) {
        echo "Default categories created.\n";
    } else {
        echo "Warning: No categories found.\n";
    }
    
    echo "\nDatabase initialization completed successfully.\n";
    
} catch (PDOException $e) {
    die("Database initialization failed: " . $e->getMessage() . "\n");
}