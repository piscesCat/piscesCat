<?php

include '../intercept.php';

function safe_shell_exec($command, &$error = '') {
    if (!function_exists('shell_exec')) {
        $error = 'Hàm shell_exec bị vô hiệu hóa.';
        return '';
    }

    $disabled = explode(',', ini_get('disable_functions'));
    $disabled = array_map('trim', $disabled);
    if (in_array('shell_exec', $disabled)) {
        $error = 'shell_exec bị vô hiệu hóa bởi cấu hình PHP.';
        return '';
    }

    $output = shell_exec($command . ' 2>&1');
    if ($output === null || trim($output) === '') {
        $error = "Lệnh không trả kết quả hoặc thất bại: $command";
    }

    return $output;
}

function detectOS($ua) {
    if (stripos($ua, 'iPhone') !== false) return 'iOS (iPhone)';
    if (stripos($ua, 'iPad') !== false) return 'iOS (iPad)';
    if (stripos($ua, 'Android') !== false) return 'Android';
    if (stripos($ua, 'Mac OS') !== false) return 'macOS';
    if (stripos($ua, 'Windows NT') !== false) return 'Windows';
    if (stripos($ua, 'Linux') !== false) return 'Linux';
    return 'Không xác định';
}

$userIp = $_SERVER['REMOTE_ADDR'];
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$os = detectOS($userAgent);
$message = '';
$showPasswordForm = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userType = $_POST['userType'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($userType === 'guest') {
        $error = '';
        $out = safe_shell_exec("sudo /usr/local/bin/nft-add-safe authed_guests $userIp 7200", $error);
		$out = safe_shell_exec("iptables -t nat -I PREROUTING -s $userIp -j ACCEPT");
		$out = safe_shell_exec("iptables -I FORWARD -s $userIp -j ACCEPT");

        if (!empty($error)) {
            $message = '❌ Không thể cấp quyền truy cập. ' . htmlspecialchars($error);
        } else {
            $message = '✅ Kết nối thành công với tư cách KHÁCH. Bạn có thể sử dụng Internet trong 120 phút.';
        }

    } elseif ($userType === 'login' && empty($password)) {
        $showPasswordForm = true;

    } elseif ($userType === 'login' && !empty($password)) {
        if ($password === '88888888@') {
            $error = '';
            $out = safe_shell_exec("sudo /usr/local/bin/nft-add-safe authed_users $userIp 0", $error);
			$out = safe_shell_exec("iptables -t nat -I PREROUTING -s $userIp -j ACCEPT");
			$out = safe_shell_exec("iptables -I FORWARD -s $userIp -j ACCEPT");
			
            if (!empty($error)) {
                $message = '❌ Không thể cấp quyền truy cập. ' . htmlspecialchars($error);
            } else {
                $message = '✅ Đăng nhập thành công. Quyền truy cập đầy đủ đã được cấp.';
            }
        } else {
            $message = '❌ Sai mật khẩu. Vui lòng thử lại.';
            $showPasswordForm = true;
        }
    } else {
        $message = '❌ Dữ liệu gửi lên không hợp lệ.';
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Wi-Fi Captive Portal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      background: #eef5ff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 420px;
      margin: 60px auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 24px rgba(0,0,0,0.1);
      text-align: center;
    }

    h2 {
      color: #007bff;
      margin-bottom: 15px;
    }

    .info {
      color: #555;
      font-size: 0.95rem;
      margin-bottom: 25px;
    }

    .btn {
      padding: 12px;
      font-size: 1rem;
      border-radius: 8px;
      border: none;
      width: 48%;
      margin: 5px 1%;
      cursor: pointer;
    }

    .btn-guest {
      background: #f0f0f0;
      color: #333;
    }

    .btn-login {
      background: #007bff;
      color: #fff;
    }

    .btn-submit {
      background: #28a745;
      color: #fff;
      width: 100%;
      margin-top: 15px;
    }

    input[type="password"] {
      width: 100%;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-top: 10px;
      font-size: 1rem;
    }

    .alert {
      padding: 12px;
      margin-bottom: 15px;
      border-radius: 6px;
    }

    .alert-success {
      background: #d4edda;
      color: #155724;
    }

    .alert-danger {
      background: #f8d7da;
      color: #721c24;
    }

    .device {
      margin-top: 25px;
      font-size: 0.9rem;
      text-align: left;
      color: #444;
    }

    .device ul {
      padding-left: 1rem;
      list-style: none;
    }

    .device li {
      margin-bottom: 6px;
    }

    footer {
      margin-top: 40px;
      text-align: center;
      font-size: 0.8rem;
      color: #aaa;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>📶 Cổng kết nối Wi-Fi</h2>
    <p class="info">
      Vui lòng chọn loại kết nối phù hợp.<br>
      Nếu bạn là thành viên gia đình, hãy nhập mật khẩu để truy cập mạng.
    </p>

    <?php if (!empty($message)): ?>
      <div class="alert <?php echo (strpos($message, '✅') !== false) ? 'alert-success' : 'alert-danger'; ?>">
        <?php echo nl2br(htmlspecialchars($message)); ?>
      </div>
    <?php endif; ?>

    <?php if ($showPasswordForm): ?>
      <form method="post">
        <input type="hidden" name="userType" value="login">
        <input type="password" name="password" placeholder="Nhập mật khẩu" required>
        <button type="submit" class="btn btn-submit">🔐 Kết nối</button>
      </form>
    <?php else: ?>
      <form method="post">
        <button type="submit" name="userType" value="guest" class="btn btn-guest">🧳 Khách</button>
        <button type="submit" name="userType" value="login" class="btn btn-login">🏠 Đăng nhập</button>
      </form>
    <?php endif; ?>

    <div class="device">
      <strong>🖥️ Thông tin thiết bị:</strong>
      <ul>
        <li><strong>IP:</strong> <?php echo htmlspecialchars($userIp); ?></li>
        <li><strong>Hệ điều hành:</strong> <?php echo htmlspecialchars($os); ?></li>
      </ul>
    </div>
  </div>

  <footer>
    &copy; <?php echo date('Y'); ?> Wi-Fi Portal
  </footer>
</body>
</html>