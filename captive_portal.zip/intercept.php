<?php

$captiveHosts = [
    'msftconnecttest.com','msftncsi.com','dns.msftncsi.com','ipv6.msftconnecttest.com',
    'captive.apple.com','apple.com','gsp1.apple.com','airport.us','akamaitechnologies.com','akamaiedge.net','apple.com.edgekey.net',
    'connectivitycheck.gstatic.com','clients3.google.com','clients4.google.com','gstatic.com',
    'nmcheck.gnome.org','networkcheck.kde.org',
    'spectrum.s3.amazonaws.com',
    'detectportal.firefox.com','detectportal.brave-http-only.com',
    'cloudflareportal.com','cloudflarecp.com','cloudflareok.com',
    'connectivity.cloudflareclient.com','connectivity-check.warp-svc',
];

$host = strtolower($_SERVER['HTTP_HOST'] ?? '');

foreach ($captiveHosts as $h) {
    if ($host === $h) {
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Location: http://captive.portal', true, 302);
        exit;
    }
}

/*if ($host !== 'captive.portal') {
    http_response_code(403);
    echo '403 Forbidden';
    exit;
}*/
