<?php
namespace App\Models;

use CodeIgniter\Model;

class ChapterModel extends Model
{
    protected $table = 'chapters';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'story_id', 'chapter_number', 'title', 
        'content', 'views', 'status'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'story_id' => 'required|integer|is_not_unique[stories.id]',
        'chapter_number' => 'required|integer|greater_than[0]',
        'title' => 'required|min_length[1]|max_length[200]',
        'content' => 'required|min_length[100]',
        'status' => 'required|in_list[draft,published]'
    ];

    protected $validationMessages = [
        'story_id' => [
            'required' => 'ID truyện là bắt buộc',
            'is_not_unique' => 'Truyện không tồn tại'
        ],
        'chapter_number' => [
            'required' => 'Số chương là bắt buộc',
            'greater_than' => 'Số chương phải lớn hơn 0'
        ],
        'content' => [
            'required' => 'Nội dung chương là bắt buộc',
            'min_length' => 'Nội dung chương phải có ít nhất 100 ký tự'
        ]
    ];

    public function getChaptersByStory($storyId, $limit = 50, $offset = 0)
    {
        return $this->where('story_id', $storyId)
                    ->where('status', 'published')
                    ->orderBy('chapter_number', 'DESC')
                    ->findAll($limit, $offset);
    }

    public function getChapter($storyId, $chapterNumber)
    {
        return $this->where('story_id', $storyId)
                    ->where('chapter_number', $chapterNumber)
                    ->where('status', 'published')
                    ->first();
    }

    public function getNextChapter($storyId, $currentChapter)
    {
        return $this->where('story_id', $storyId)
                    ->where('chapter_number >', $currentChapter)
                    ->where('status', 'published')
                    ->orderBy('chapter_number', 'ASC')
                    ->first();
    }

    public function getPreviousChapter($storyId, $currentChapter)
    {
        return $this->where('story_id', $storyId)
                    ->where('chapter_number <', $currentChapter)
                    ->where('status', 'published')
                    ->orderBy('chapter_number', 'DESC')
                    ->first();
    }

    public function incrementViews($id)
    {
        return $this->set('views', 'views + 1', false)
                    ->where('id', $id)
                    ->update();
    }

    public function getLatestChapters($limit = 20)
    {
        return $this->select('chapters.*, stories.title as story_title, stories.slug as story_slug')
                    ->join('stories', 'stories.id = chapters.story_id')
                    ->where('chapters.status', 'published')
                    ->where('stories.status', 'published')
                    ->orderBy('chapters.created_at', 'DESC')
                    ->findAll($limit);
    }
}