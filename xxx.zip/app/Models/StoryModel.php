<?php
namespace App\Models;

use CodeIgniter\Model;

class StoryModel extends Model
{
    protected $table = 'stories';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'title', 'slug', 'description', 'cover_image',
        'author_id', 'status', 'views', 'rating'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'title' => 'required|min_length[3]|max_length[200]',
        'slug' => 'required|alpha_dash|min_length[3]|max_length[200]|is_unique[stories.slug,id,{id}]',
        'description' => 'required|min_length[10]',
        'author_id' => 'required|integer',
        'status' => 'required|in_list[draft,published,completed]'
    ];

    protected $validationMessages = [
        'title' => [
            'required' => 'Tiêu đề truyện là bắt buộc',
            'min_length' => 'Tiêu đề truyện phải có ít nhất 3 ký tự',
        ],
        'slug' => [
            'is_unique' => 'Đường dẫn này đã tồn tại, vui lòng chọn tiêu đề khác',
        ]
    ];

    public function getFeatured($limit = 5)
    {
        return $this->select('stories.*, users.username as author_name')
                    ->join('users', 'users.id = stories.author_id')
                    ->where('stories.status', 'published')
                    ->orderBy('stories.rating', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    public function getLatest($limit = 12)
    {
        return $this->select('stories.*, users.username as author_name,
                            (SELECT MAX(chapter_number) FROM chapters WHERE story_id = stories.id) as latest_chapter')
                    ->join('users', 'users.id = stories.author_id')
                    ->where('stories.status', 'published')
                    ->orderBy('stories.created_at', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    public function getRecentlyUpdated($limit = 6)
    {
        return $this->select('stories.*, users.username as author_name,
                             (SELECT MAX(chapter_number) FROM chapters WHERE story_id = stories.id) as latest_chapter,
                             (SELECT MAX(created_at) FROM chapters WHERE story_id = stories.id) as last_chapter_date')
                    ->join('users', 'users.id = stories.author_id')
                    ->join('chapters', 'chapters.story_id = stories.id', 'left')
                    ->where('stories.status', 'published')
                    ->groupBy('stories.id')
                    ->orderBy('last_chapter_date', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    public function getPopular($limit = 8)
    {
        return $this->select('stories.*, users.username as author_name,
                            (SELECT MAX(chapter_number) FROM chapters WHERE story_id = stories.id) as latest_chapter')
                    ->join('users', 'users.id = stories.author_id')
                    ->where('stories.status', 'published')
                    ->orderBy('stories.views', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    public function getCompleted($limit = 12)
    {
        return $this->select('stories.*, users.username as author_name,
                            (SELECT MAX(chapter_number) FROM chapters WHERE story_id = stories.id) as latest_chapter')
                    ->join('users', 'users.id = stories.author_id')
                    ->where('stories.status', 'completed')
                    ->orderBy('stories.updated_at', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    public function getByCategory($categoryId, $limit = 20, $offset = 0)
    {
        return $this->select('stories.*, users.username as author_name,
                            (SELECT MAX(chapter_number) FROM chapters WHERE story_id = stories.id) as latest_chapter')
                    ->join('users', 'users.id = stories.author_id')
                    ->join('story_categories', 'story_categories.story_id = stories.id')
                    ->where('story_categories.category_id', $categoryId)
                    ->where('stories.status', 'published')
                    ->orderBy('stories.updated_at', 'DESC')
                    ->limit($limit, $offset)
                    ->find();
    }

    public function search($keyword, $limit = 20, $offset = 0)
    {
        return $this->select('stories.*, users.username as author_name,
                            (SELECT MAX(chapter_number) FROM chapters WHERE story_id = stories.id) as latest_chapter')
                    ->join('users', 'users.id = stories.author_id')
                    ->groupStart()
                    ->like('stories.title', $keyword)
                    ->orLike('stories.description', $keyword)
                    ->orLike('users.username', $keyword)
                    ->groupEnd()
                    ->where('stories.status', 'published')
                    ->orderBy('stories.views', 'DESC')
                    ->limit($limit, $offset)
                    ->find();
    }

    public function getSearchSuggestions($keyword, $limit = 5)
    {
        return $this->select('stories.id, stories.title, stories.slug, stories.cover_image')
                    ->like('stories.title', $keyword)
                    ->where('stories.status', 'published')
                    ->orderBy('stories.views', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    public function incrementViews($id)
    {
        return $this->set('views', 'views + 1', false)
                    ->where('id', $id)
                    ->update();
    }

    public function updateRating($id)
    {
        $db = \Config\Database::connect();
        $query = $db->table('ratings')
                    ->selectAvg('rating')
                    ->where('story_id', $id)
                    ->get();
        $result = $query->getRow();

        return $this->set('rating', $result->rating ?? 0)
                    ->where('id', $id)
                    ->update();
    }

    public function getFullStoryDetails($slug)
    {
        return $this->select('stories.*, users.username as author_name, users.avatar as author_avatar,
                             (SELECT COUNT(*) FROM chapters WHERE story_id = stories.id) as total_chapters,
                             (SELECT MAX(chapter_number) FROM chapters WHERE story_id = stories.id) as latest_chapter')
                    ->join('users', 'users.id = stories.author_id')
                    ->where('stories.slug', $slug)
                    ->first();
    }
}
