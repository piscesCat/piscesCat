<?php
// app/Helpers/twig_helper.php
if (!function_exists('twig_function')) {
    function twig_function($name, $callback)
    {
        $twig = service('twig');
        $function = new \Twig\TwigFunction($name, $callback);
        $twig->addFunction($function);
    }
}

if (!function_exists('twig_filter')) {
    function twig_filter($name, $callback)
    {
        $twig = service('twig');
        $filter = new \Twig\TwigFilter($name, $callback);
        $twig->addFilter($filter);
    }
}

// Add custom Twig functions
twig_function('base_url', function($uri = '') {
    return base_url($uri);
});

twig_function('site_url', function($uri = '') {
    return site_url($uri);
});

twig_function('current_url', function() {
    return current_url();
});

twig_function('form_open', function($action = '', $attributes = [], $hidden = []) {
    return form_open($action, $attributes, $hidden);
});

twig_function('form_close', function() {
    return form_close();
});

twig_function('csrf_field', function() {
    return csrf_field();
});

// Add new functions for story website
twig_function('get_story_categories', function($story_id) {
    $db = \Config\Database::connect();
    $query = $db->table('story_categories')
                ->select('categories.name, categories.slug')
                ->join('categories', 'categories.id = story_categories.category_id')
                ->where('story_id', $story_id)
                ->get();
    return $query->getResultArray();
});

twig_function('get_latest_chapters', function($story_id, $limit = 5) {
    $db = \Config\Database::connect();
    $query = $db->table('chapters')
                ->where('story_id', $story_id)
                ->where('status', 'published')
                ->orderBy('chapter_number', 'DESC')
                ->limit($limit)
                ->get();
    return $query->getResultArray();
});

twig_function('count_story_comments', function($story_id) {
    $db = \Config\Database::connect();
    return $db->table('comments')
              ->where('story_id', $story_id)
              ->countAllResults();
});

twig_function('format_number', function($number) {
    if ($number >= 1000000) {
        return round($number / 1000000, 1) . 'M';
    } elseif ($number >= 1000) {
        return round($number / 1000, 1) . 'K';
    }
    return $number;
});

// Add custom Twig filters
twig_filter('limit_text', function($text, $limit = 100) {
    if (strlen($text) > $limit) {
        return substr($text, 0, $limit) . '...';
    }
    return $text;
});

twig_filter('time_ago', function($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;

    if ($diff < 60) {
        return 'vừa xong';
    } elseif ($diff < 3600) {
        return floor($diff / 60) . ' phút trước';
    } elseif ($diff < 86400) {
        return floor($diff / 3600) . ' giờ trước';
    } elseif ($diff < 2592000) {
        return floor($diff / 86400) . ' ngày trước';
    } else {
        return date('d/m/Y', $time);
    }
});

// SEO-related filters
twig_filter('meta_description', function($text) {
    // Clean the text for meta description
    $text = strip_tags($text);
    $text = str_replace(["\n", "\r", "\t"], ' ', $text);
    $text = preg_replace('/\s+/', ' ', $text);
    return substr(trim($text), 0, 160);
});

twig_filter('slug', function($text) {
    // Convert to lowercase
    $text = strtolower($text);
    // Replace Vietnamese characters
    $text = preg_replace('/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/', 'a', $text);
    $text = preg_replace('/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/', 'e', $text);
    $text = preg_replace('/(ì|í|ị|ỉ|ĩ)/', 'i', $text);
    $text = preg_replace('/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/', 'o', $text);
    $text = preg_replace('/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/', 'u', $text);
    $text = preg_replace('/(ỳ|ý|ỵ|ỷ|ỹ)/', 'y', $text);
    $text = preg_replace('/(đ)/', 'd', $text);
    // Remove special characters
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    // Replace all spaces with hyphens
    $text = preg_replace('/\s+/', '-', $text);
    // Remove duplicate hyphens
    $text = preg_replace('/-+/', '-', $text);
    // Trim hyphens from beginning and end
    return trim($text, '-');
});
