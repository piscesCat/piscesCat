<?php
// app/Controllers/BaseController.php
namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 */
abstract class BaseController extends Controller
{
    /**
     * Instance of the main Request object.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;

    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers = ['url', 'form'];

    /**
     * Constructor.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Preload any models, libraries, etc, here.
        $this->session = \Config\Services::session();
        $this->twig = service('twig');

        // Set common variables
        $this->setCommonViewVariables();
    }

    /**
     * Render a view with Twig
     */
    protected function render(string $view, array $data = [], array $options = [])
    {
        // Replace .twig extension with .html if needed
        $view = str_replace('.twig', '.html', $view);

        // Render with Twig
        echo $this->twig->render($view, $data);
    }

    /**
     * Set common variables for all views
     */
    protected function setCommonViewVariables()
    {
        // Current user info
        $currentUser = null;
        if ($this->session->has('user_id')) {
            $userModel = new \App\Models\UserModel();
            $currentUser = $userModel->find($this->session->get('user_id'));
        }
        $this->twig->addGlobal('current_user', $currentUser);

        // Base URL
        $this->twig->addGlobal('base_url', base_url());

        // Categories for navigation
        $categoryModel = new \App\Models\CategoryModel();
        $categories = $categoryModel->getCategoriesWithCount();
        $this->twig->addGlobal('categories', $categories);
    }
}
