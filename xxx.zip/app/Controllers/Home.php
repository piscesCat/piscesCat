<?php
// app/Controllers/Home.php
namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $storyModel = new \App\Models\StoryModel();
        $categoryModel = new \App\Models\CategoryModel();

        // Get all categories with story count
        $categories = $categoryModel->getCategoriesWithCount();

        // Get featured/highlighted stories
        $featured_stories = $storyModel->getFeatured(6);

        // Get newest stories
        $latest_stories = $storyModel->getLatest(12);

        // Get popular stories
        $popular_stories = $storyModel->getPopular(5);

        // Get recently updated stories
        $updated_stories = $storyModel->getRecentlyUpdated(6);

        // Get top authors
        $db = \Config\Database::connect();
        $query = $db->table('users')
                    ->select('users.id, users.username, users.avatar, COUNT(stories.id) as story_count')
                    ->join('stories', 'stories.author_id = users.id')
                    ->where('stories.status', 'published')
                    ->groupBy('users.id')
                    ->orderBy('story_count', 'DESC')
                    ->limit(5)
                    ->get();
        $top_authors = $query->getResultArray();

        return view('home.html', [
            'categories' => $categories,
            'featured_stories' => $featured_stories,
            'latest_stories' => $latest_stories,
            'popular_stories' => $popular_stories,
            'updated_stories' => $updated_stories,
            'top_authors' => $top_authors
        ]);
    }
}
