<?php
namespace Config;

use CodeIgniter\Config\BaseConfig;

class Twig extends BaseConfig
{
    /**
     * Twig Environment options
     *
     * @var array
     */
    public $config = [
        'debug' => true,
        'charset' => 'UTF-8',
        'strict_variables' => false,
        'autoescape' => 'html',
        'cache' => WRITEPATH . 'cache/twig',
        'auto_reload' => true,
    ];

    /**
     * Extensions to register
     *
     * @var array
     */
    public $extensions = [];

    /**
     * File extensions
     *
     * @var array
     */
    public $fileExtensions = [
        'html', // Using HTML extension for Twig templates
        'twig', // Also support legacy .twig extension
    ];
}
