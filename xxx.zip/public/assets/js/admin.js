/**
 * Admin JavaScript for Truyện HOT
 */
$(document).ready(function() {
    'use strict';

    // Initialize DataTables for all admin tables
    if ($('.datatable').length > 0) {
        $('.datatable').each(function() {
            const $table = $(this);
            const options = {
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/vi.json'
                },
                responsive: true,
                pageLength: 25,
                columnDefs: [
                    { orderable: false, targets: 'no-sort' }
                ]
            };

            // If specified, load data via AJAX
            if ($table.data('ajax-url')) {
                options.serverSide = true;
                options.ajax = {
                    url: $table.data('ajax-url'),
                    type: 'POST'
                };
            }

            $table.DataTable(options);
        });
    }

    // Initialize Summernote editor
    if ($('.summernote').length > 0) {
        $('.summernote').each(function() {
            $(this).summernote({
                height: 300,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'clear']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['table', ['table']],
                    ['insert', ['link', 'picture']],
                    ['view', ['fullscreen', 'codeview', 'help']]
                ],
                callbacks: {
                    onImageUpload: function(files) {
                        uploadSummernoteImage(files[0], $(this));
                    }
                }
            });
        });
    }

    // Upload image from Summernote
    function uploadSummernoteImage(file, editor) {
        const formData = new FormData();
        formData.append('file', file);

        $.ajax({
            url: BASE_URL + '/admin/uploads/upload-image',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    editor.summernote('insertImage', response.file_url);
                } else {
                    showToast(response.message || 'Lỗi khi tải lên hình ảnh', 'error');
                }
            },
            error: function() {
                showToast('Lỗi khi tải lên hình ảnh', 'error');
            }
        });
    }

    // Image preview on file input change
    $('.image-upload').on('change', function() {
        const file = this.files[0];
        const previewId = $(this).data('preview');
        const $preview = $('#' + previewId);

        if ($preview.length && file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $preview.attr('src', e.target.result);
                $preview.removeClass('d-none');
            };
            reader.readAsDataURL(file);
        }
    });

    // Story management
    // ======================

    // Story slug generator
    $('#title').on('blur', function() {
        if ($('#slug').val() === '') {
            const title = $(this).val();
            if (title) {
                $.ajax({
                    url: BASE_URL + '/admin/stories/generate-slug',
                    method: 'POST',
                    data: { title: title },
                    success: function(response) {
                        if (response.success) {
                            $('#slug').val(response.slug);
                        }
                    }
                });
            }
        }
    });

    // Delete story confirmation
    $('.btn-delete-story').on('click', function() {
        const storyId = $(this).data('id');
        const storyTitle = $(this).data('title');

        if (confirm(`Bạn có chắc chắn muốn xóa truyện "${storyTitle}"?`)) {
            $.ajax({
                url: BASE_URL + '/admin/stories/ajax-delete',
                method: 'POST',
                data: { id: storyId },
                success: function(response) {
                    if (response.success) {
                        showToast(response.message);
                        $(`tr[data-story-id="${storyId}"]`).fadeOut(function() {
                            $(this).remove();
                        });
                    } else {
                        showToast(response.message || 'Không thể xóa truyện', 'error');
                    }
                },
                error: function() {
                    showToast('Đã xảy ra lỗi khi xóa truyện', 'error');
                }
            });
        }
    });

    // Chapter management
    // ======================

    // Delete chapter confirmation
    $('.btn-delete-chapter').on('click', function() {
        const chapterId = $(this).data('id');
        const chapterTitle = $(this).data('title');

        if (confirm(`Bạn có chắc chắn muốn xóa chương "${chapterTitle}"?`)) {
            $.ajax({
                url: BASE_URL + '/admin/chapters/ajax-delete',
                method: 'POST',
                data: { id: chapterId },
                success: function(response) {
                    if (response.success) {
                        showToast(response.message);
                        $(`tr[data-chapter-id="${chapterId}"]`).fadeOut(function() {
                            $(this).remove();
                        });
                    } else {
                        showToast(response.message || 'Không thể xóa chương', 'error');
                    }
                },
                error: function() {
                    showToast('Đã xảy ra lỗi khi xóa chương', 'error');
                }
            });
        }
    });

    // Quick edit chapter
    $('.btn-quick-edit-chapter').on('click', function() {
        const chapterId = $(this).data('id');

        // Show loading
        $('#quickEditModal .modal-body').html('<div class="text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>');
        $('#quickEditModal').modal('show');

        // Load chapter data
        $.ajax({
            url: BASE_URL + '/admin/chapters/get-chapter',
            method: 'GET',
            data: { id: chapterId },
            success: function(response) {
                if (response.success) {
                    const chapter = response.chapter;

                    // Create form HTML
                    const html = `
                        <form id="quickEditForm">
                            <input type="hidden" name="id" value="${chapter.id}">
                            <div class="mb-3">
                                <label for="chapter_number" class="form-label">Số chương</label>
                                <input type="number" class="form-control" id="chapter_number" name="chapter_number" value="${chapter.chapter_number}" required>
                            </div>
                            <div class="mb-3">
                                <label for="title" class="form-label">Tiêu đề</label>
                                <input type="text" class="form-control" id="title" name="title" value="${chapter.title}" required>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Trạng thái</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="draft" ${chapter.status === 'draft' ? 'selected' : ''}>Bản nháp</option>
                                    <option value="published" ${chapter.status === 'published' ? 'selected' : ''}>Đã xuất bản</option>
                                </select>
                            </div>
                        </form>
                    `;

                    $('#quickEditModal .modal-body').html(html);

                    // Set up form submission
                    $('#quickEditForm').on('submit', function(e) {
                        e.preventDefault();
                        saveQuickEdit();
                    });
                } else {
                    $('#quickEditModal .modal-body').html(`<div class="alert alert-danger">${response.message || 'Không thể tải dữ liệu chương'}</div>`);
                }
            },
            error: function() {
                $('#quickEditModal .modal-body').html('<div class="alert alert-danger">Đã xảy ra lỗi khi tải dữ liệu chương</div>');
            }
        });
    });

    // Save quick edit chapter
    function saveQuickEdit() {
        const formData = $('#quickEditForm').serialize();

        $.ajax({
            url: BASE_URL + '/admin/chapters/ajax-save',
            method: 'POST',
            data: formData,
            beforeSend: function() {
                $('#quickEditModal .modal-footer .btn-primary').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Đang lưu...');
            },
            success: function(response) {
                if (response.success) {
                    showToast(response.message);

                    // Update row in table
                    const chapterId = $('#quickEditForm input[name="id"]').val();
                    const $row = $(`tr[data-chapter-id="${chapterId}"]`);
                    $row.find('.chapter-number').text($('#quickEditForm input[name="chapter_number"]').val());
                    $row.find('.chapter-title').text($('#quickEditForm input[name="title"]').val());
                    $row.find('.chapter-status').html(getStatusBadge($('#quickEditForm select[name="status"]').val()));

                    // Close modal
                    $('#quickEditModal').modal('hide');
                } else {
                    showToast(response.message || 'Không thể lưu dữ liệu chương', 'error');
                }
            },
            error: function() {
                showToast('Đã xảy ra lỗi khi lưu dữ liệu chương', 'error');
            },
            complete: function() {
                $('#quickEditModal .modal-footer .btn-primary').prop('disabled', false).html('Lưu thay đổi');
            }
        });
    }

    // Get status badge HTML
    function getStatusBadge(status) {
        if (status === 'published') {
            return '<span class="badge bg-success">Đã xuất bản</span>';
        } else if (status === 'draft') {
            return '<span class="badge bg-secondary">Bản nháp</span>';
        }
        return '<span class="badge bg-light text-dark">Không xác định</span>';
    }

    // Quick save button in modal
    $('#quickEditModal .btn-primary').on('click', function() {
        $('#quickEditForm').submit();
    });

    // Category management
    // ======================

    // Delete category confirmation
    $('.btn-delete-category').on('click', function() {
        const categoryId = $(this).data('id');
        const categoryName = $(this).data('name');

        if (confirm(`Bạn có chắc chắn muốn xóa thể loại "${categoryName}"?`)) {
            $.ajax({
                url: BASE_URL + '/admin/categories/ajax-delete',
                method: 'POST',
                data: { id: categoryId },
                success: function(response) {
                    if (response.success) {
                        showToast(response.message);
                        $(`tr[data-category-id="${categoryId}"]`).fadeOut(function() {
                            $(this).remove();
                        });
                    } else {
                        showToast(response.message || 'Không thể xóa thể loại', 'error');
                    }
                },
                error: function() {
                    showToast('Đã xảy ra lỗi khi xóa thể loại', 'error');
                }
            });
        }
    });

    // User management
    // ======================

    // Delete user confirmation
    $('.btn-delete-user').on('click', function() {
        const userId = $(this).data('id');
        const username = $(this).data('username');

        if (confirm(`Bạn có chắc chắn muốn xóa người dùng "${username}"?`)) {
            $.ajax({
                url: BASE_URL + '/admin/users/ajax-delete',
                method: 'POST',
                data: { id: userId },
                success: function(response) {
                    if (response.success) {
                        showToast(response.message);
                        $(`tr[data-user-id="${userId}"]`).fadeOut(function() {
                            $(this).remove();
                        });
                    } else {
                        showToast(response.message || 'Không thể xóa người dùng', 'error');
                    }
                },
                error: function() {
                    showToast('Đã xảy ra lỗi khi xóa người dùng', 'error');
                }
            });
        }
    });

    // Update user status
    $('.btn-toggle-user-status').on('click', function() {
        const userId = $(this).data('id');
        const currentStatus = $(this).data('status');
        const newStatus = currentStatus === 'active' ? 'banned' : 'active';

        $.ajax({
            url: BASE_URL + '/admin/users/ajax-update-status',
            method: 'POST',
            data: {
                id: userId,
                status: newStatus
            },
            success: function(response) {
                if (response.success) {
                    showToast(response.message);

                    // Update button and cell
                    const $btn = $(`.btn-toggle-user-status[data-id="${userId}"]`);
                    const $cell = $btn.closest('tr').find('.user-status');

                    $btn.data('status', newStatus)
                        .removeClass(currentStatus === 'active' ? 'btn-danger' : 'btn-success')
                        .addClass(newStatus === 'active' ? 'btn-danger' : 'btn-success')
                        .html(newStatus === 'active' ? '<i class="fas fa-ban"></i>' : '<i class="fas fa-check"></i>');

                    $cell.html(getUserStatusBadge(newStatus));
                } else {
                    showToast(response.message || 'Không thể cập nhật trạng thái người dùng', 'error');
                }
            },
            error: function() {
                showToast('Đã xảy ra lỗi khi cập nhật trạng thái người dùng', 'error');
            }
        });
    });

    // Get user status badge HTML
    function getUserStatusBadge(status) {
        if (status === 'active') {
            return '<span class="badge bg-success">Hoạt động</span>';
        } else if (status === 'banned') {
            return '<span class="badge bg-danger">Bị khóa</span>';
        }
        return '<span class="badge bg-secondary">Không xác định</span>';
    }

    // Dashboard
    // ======================

    // Initialize charts if on dashboard
    if ($('#visitsChart').length > 0) {
        initDashboardCharts();
    }

    function initDashboardCharts() {
        // Visits chart
        const visitsChartEl = document.getElementById('visitsChart');
        const visitsChart = new Chart(visitsChartEl, {
            type: 'line',
            data: {
                labels: Array.from({ length: 7 }, (_, i) => {
                    const d = new Date();
                    d.setDate(d.getDate() - (6 - i));
                    return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
                }),
                datasets: [{
                    label: 'Lượt xem',
                    data: [0, 0, 0, 0, 0, 0, 0], // Will be loaded via AJAX
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#adb5bd'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#adb5bd'
                        }
                    }
                }
            }
        });

        // Load chart data
        $.ajax({
            url: BASE_URL + '/admin/dashboard/stats',
            method: 'GET',
            success: function(response) {
                if (response.success) {
                    // Update visits chart
                    visitsChart.data.datasets[0].data = response.visits_data;
                    visitsChart.update();
                }
            }
        });
    }

    // File Manager
    // ======================

    // Delete file confirmation
    $('.btn-delete-file').on('click', function() {
        const filePath = $(this).data('path');
        const fileName = $(this).data('name');

        if (confirm(`Bạn có chắc chắn muốn xóa tệp "${fileName}"?`)) {
            $.ajax({
                url: BASE_URL + '/admin/uploads/ajax-delete',
                method: 'POST',
                data: { path: filePath },
                success: function(response) {
                    if (response.success) {
                        showToast(response.message);
                        $(`.file-item[data-path="${filePath}"]`).fadeOut(function() {
                            $(this).remove();
                        });
                    } else {
                        showToast(response.message || 'Không thể xóa tệp', 'error');
                    }
                },
                error: function() {
                    showToast('Đã xảy ra lỗi khi xóa tệp', 'error');
                }
            });
        }
    });

    // Dropzone for file uploads
    if ($('#fileUpload').length > 0) {
        const myDropzone = new Dropzone('#fileUpload', {
            url: BASE_URL + '/admin/uploads/upload',
            paramName: 'file',
            maxFilesize: 5, // MB
            maxFiles: 10,
            acceptedFiles: 'image/*,.pdf,.doc,.docx,.txt',
            dictDefaultMessage: 'Kéo và thả tệp vào đây hoặc nhấp để tải lên',
            init: function() {
                this.on('success', function(file, response) {
                    if (response.success) {
                        showToast('Tải lên thành công');

                        // If auto-reload is enabled, reload the page after all uploads complete
                        if (this.getQueuedFiles().length === 0 && this.getUploadingFiles().length === 0) {
                            setTimeout(function() {
                                window.location.reload();
                            }, 1000);
                        }
                    } else {
                        showToast(response.message || 'Lỗi khi tải tệp lên', 'error');
                    }
                });

                this.on('error', function(file, message) {
                    showToast(message, 'error');
                });
            }
        });
    }
});
