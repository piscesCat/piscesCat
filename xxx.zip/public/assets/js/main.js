/**
 * Main JavaScript for Truyện HOT
 */
$(document).ready(function() {
    'use strict';

    // Global Ajax Setup
    $.ajaxSetup({
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    // Show loading indicator for all AJAX requests
    $(document).ajaxStart(function() {
        showLoading();
    }).ajaxStop(function() {
        hideLoading();
    });

    /**
     * Loading Indicator
     */
    function showLoading() {
        if ($('.ajax-loading').length === 0) {
            $('body').append(`
                <div class="ajax-loading">
                    <div class="spinner-border text-light" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            `);
        }
    }

    function hideLoading() {
        $('.ajax-loading').remove();
    }

    /**
     * Toast Notifications
     */
    function showToast(message, type = 'success') {
        const toastId = 'toast-' + Math.random().toString(36).substr(2, 9);
        const toastHtml = `
            <div class="toast" id="${toastId}" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="5000">
                <div class="toast-header ${type === 'success' ? 'bg-success' : 'bg-danger'} text-white">
                    <strong class="me-auto">${type === 'success' ? 'Thành công' : 'Lỗi'}</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;

        // Create toast container if it doesn't exist
        if ($('.toast-container').length === 0) {
            $('body').append('<div class="toast-container"></div>');
        }

        // Add and show toast
        $('.toast-container').append(toastHtml);
        const toastElement = new bootstrap.Toast(document.getElementById(toastId));
        toastElement.show();

        // Remove toast after hidden
        $(`#${toastId}`).on('hidden.bs.toast', function() {
            $(this).remove();
        });
    }

    /**
     * Story Rating
     */
    $('.rating-stars .star').on('click', function() {
        const storyId = $(this).closest('.rating-stars').data('story-id');
        const rating = $(this).data('rating');

        if (storyId && rating) {
            $.ajax({
                url: BASE_URL + '/story/rate',
                type: 'POST',
                data: {
                    story_id: storyId,
                    rating: rating
                },
                success: function(response) {
                    if (response.success) {
                        $('.rating-stars .star').removeClass('active');
                        $(`.rating-stars .star[data-rating="${rating}"]`).addClass('active');
                        $('.current-rating').text(response.average_rating.toFixed(1));
                        showToast('Cảm ơn bạn đã đánh giá truyện!');
                    }
                },
                error: function() {
                    showToast('Có lỗi xảy ra khi đánh giá truyện.', 'error');
                }
            });
        }
    });

    /**
     * Bookmark Story
     */
    $('.btn-bookmark').on('click', function() {
        const storyId = $(this).data('story-id');
        const $bookmarkBtn = $(this);
        const isBookmarked = $bookmarkBtn.hasClass('active');

        if (storyId) {
            $.ajax({
                url: BASE_URL + '/story/bookmark',
                type: 'POST',
                data: {
                    story_id: storyId,
                    action: isBookmarked ? 'remove' : 'add'
                },
                success: function(response) {
                    if (response.success) {
                        if (isBookmarked) {
                            $bookmarkBtn.removeClass('active').find('.bookmark-text').text('Đánh dấu');
                        } else {
                            $bookmarkBtn.addClass('active').find('.bookmark-text').text('Đã đánh dấu');
                        }
                        showToast(response.message);
                    }
                },
                error: function(xhr) {
                    if (xhr.status === 401) {
                        window.location.href = BASE_URL + '/login?redirect=' + encodeURIComponent(window.location.href);
                    } else {
                        showToast('Có lỗi xảy ra khi thực hiện thao tác.', 'error');
                    }
                }
            });
        }
    });

    /**
     * Comment Submission
     */
    $('#commentForm').on('submit', function(e) {
        e.preventDefault();
        const $form = $(this);
        const storyId = $form.find('input[name="story_id"]').val();
        const chapterId = $form.find('input[name="chapter_id"]').val();
        const content = $form.find('textarea[name="content"]').val();

        if (content.trim() === '') {
            showToast('Vui lòng nhập nội dung bình luận.', 'error');
            return;
        }

        $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            data: $form.serialize(),
            success: function(response) {
                if (response.success) {
                    $form.find('textarea[name="content"]').val('');

                    // Add new comment to the list
                    const newComment = `
                        <div class="comment-item">
                            <div class="d-flex align-items-center">
                                <img src="${response.comment.user_avatar || BASE_URL + '/assets/images/default-avatar.png'}" class="comment-avatar me-2">
                                <div>
                                    <strong>${response.comment.username}</strong>
                                    <small class="text-muted ms-2">${response.comment.created_at}</small>
                                </div>
                            </div>
                            <div class="comment-content">
                                ${response.comment.content}
                            </div>
                        </div>
                    `;
                    $('.comment-list').prepend(newComment);
                    showToast('Bình luận của bạn đã được đăng thành công.');
                }
            },
            error: function(xhr) {
                if (xhr.status === 401) {
                    window.location.href = BASE_URL + '/login?redirect=' + encodeURIComponent(window.location.href);
                } else {
                    showToast('Có lỗi xảy ra khi đăng bình luận.', 'error');
                }
            }
        });
    });

    /**
     * Admin AJAX Functions
     */
    if ($('.admin-content').length > 0) {
        // Story Management - Delete
        $('.btn-delete-story').on('click', function() {
            const storyId = $(this).data('id');
            const storyTitle = $(this).data('title');

            if (confirm(`Bạn có chắc chắn muốn xóa truyện "${storyTitle}" không?`)) {
                $.ajax({
                    url: BASE_URL + '/admin/stories/ajax-delete',
                    type: 'POST',
                    data: { id: storyId },
                    success: function(response) {
                        if (response.success) {
                            showToast(response.message);
                            $(`tr[data-story-id="${storyId}"]`).fadeOut(500, function() {
                                $(this).remove();
                            });
                        }
                    },
                    error: function() {
                        showToast('Có lỗi xảy ra khi xóa truyện.', 'error');
                    }
                });
            }
        });

        // Chapter Management - Quick Edit
        $('.btn-quick-edit-chapter').on('click', function() {
            const chapterId = $(this).data('id');

            $.ajax({
                url: BASE_URL + '/admin/chapters/get-chapter',
                type: 'GET',
                data: { id: chapterId },
                success: function(response) {
                    if (response.success) {
                        const chapter = response.chapter;
                        $('#quickEditModal').find('input[name="id"]').val(chapter.id);
                        $('#quickEditModal').find('input[name="chapter_number"]').val(chapter.chapter_number);
                        $('#quickEditModal').find('input[name="title"]').val(chapter.title);
                        $('#quickEditModal').find('select[name="status"]').val(chapter.status);

                        // Show modal
                        new bootstrap.Modal(document.getElementById('quickEditModal')).show();
                    }
                },
                error: function() {
                    showToast('Có lỗi xảy ra khi tải dữ liệu chương.', 'error');
                }
            });
        });

        // Save Quick Edit Chapter
        $('#quickEditForm').on('submit', function(e) {
            e.preventDefault();
            const $form = $(this);

            $.ajax({
                url: BASE_URL + '/admin/chapters/ajax-save',
                type: 'POST',
                data: $form.serialize(),
                success: function(response) {
                    if (response.success) {
                        showToast(response.message);

                        // Update row in table
                        const chapterId = $form.find('input[name="id"]').val();
                        const $row = $(`tr[data-chapter-id="${chapterId}"]`);
                        $row.find('.chapter-number').text($form.find('input[name="chapter_number"]').val());
                        $row.find('.chapter-title').text($form.find('input[name="title"]').val());
                        $row.find('.chapter-status').text($form.find('select[name="status"] option:selected').text());

                        // Hide modal
                        bootstrap.Modal.getInstance(document.getElementById('quickEditModal')).hide();
                    }
                },
                error: function() {
                    showToast('Có lỗi xảy ra khi lưu dữ liệu chương.', 'error');
                }
            });
        });
    }

    /**
     * Reading Settings
     */
    // Font size
    $('.btn-font-size').on('click', function() {
        const size = $(this).data('size');
        const fontSize = parseInt(size);

        $('.chapter-content').css('font-size', fontSize + 'px');
        $('.btn-font-size').removeClass('active');
        $(this).addClass('active');

        // Save preference in localStorage
        localStorage.setItem('chapter_font_size', fontSize);
    });

    // Load saved font size
    const savedFontSize = localStorage.getItem('chapter_font_size');
    if (savedFontSize) {
        $('.chapter-content').css('font-size', savedFontSize + 'px');
        $(`.btn-font-size[data-size="${savedFontSize}"]`).addClass('active');
    }

    // Line height
    $('.btn-line-height').on('click', function() {
        const height = $(this).data('height');

        $('.chapter-content').css('line-height', height);
        $('.btn-line-height').removeClass('active');
        $(this).addClass('active');

        // Save preference in localStorage
        localStorage.setItem('chapter_line_height', height);
    });

    // Load saved line height
    const savedLineHeight = localStorage.getItem('chapter_line_height');
    if (savedLineHeight) {
        $('.chapter-content').css('line-height', savedLineHeight);
        $(`.btn-line-height[data-height="${savedLineHeight}"]`).addClass('active');
    }

    /**
     * Search Autocomplete
     */
    const $searchInput = $('input[name="q"]');
    if ($searchInput.length > 0) {
        const $searchResults = $('<div class="search-results dropdown-menu"></div>');
        $searchInput.after($searchResults);

        $searchInput.on('keyup', function() {
            const query = $(this).val().trim();

            if (query.length >= 2) {
                $.ajax({
                    url: BASE_URL + '/tim-kiem/suggestions',
                    type: 'GET',
                    data: { q: query },
                    success: function(response) {
                        if (response.success && response.stories.length > 0) {
                            let html = '';
                            $.each(response.stories, function(i, story) {
                                html += `
                                    <a class="dropdown-item d-flex align-items-center" href="${BASE_URL}/story/${story.slug}">
                                        <img src="${story.cover_image}" alt="${story.title}" class="img-fluid me-2" width="30">
                                        <span>${story.title}</span>
                                    </a>
                                `;
                            });
                            $searchResults.html(html).show();
                        } else {
                            $searchResults.hide();
                        }
                    }
                });
            } else {
                $searchResults.hide();
            }
        });

        // Hide search results when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.search-results, input[name="q"]').length) {
                $searchResults.hide();
            }
        });
    }

    /**
     * Initialize page-specific features
     */
    function initPageSpecificFeatures() {
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Initialize popovers
        const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        popoverTriggerList.map(function(popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });

        // Track reading progress
        if ($('.chapter-content').length > 0) {
            const storyId = $('meta[name="story-id"]').attr('content');
            const chapterId = $('meta[name="chapter-id"]').attr('content');

            if (storyId && chapterId) {
                $.ajax({
                    url: BASE_URL + '/reading-progress/update',
                    type: 'POST',
                    data: {
                        story_id: storyId,
                        chapter_id: chapterId
                    }
                });
            }
        }
    }

    // Run initialization
    initPageSpecificFeatures();
});
