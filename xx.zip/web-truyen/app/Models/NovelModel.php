<?php
namespace App\Models;

use CodeIgniter\Model;

class NovelModel extends Model
{
    protected $table = 'novels';
    protected $primaryKey = 'id';
    protected $returnType = 'object';
    protected $allowedFields = [
        'title', 'slug', 'description', 'cover_image', 'author_id',
        'status', 'views', 'rating', 'is_featured', 'is_hot', 'is_completed',
        'type', 'country', 'year', 'created_at', 'updated_at'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Get a novel by its slug
     */
    public function getBySlug($slug)
    {
        return $this->select('novels.*, users.username as author_name')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.slug', $slug)
                    ->where('novels.status', 'published')
                    ->first();
    }

    /**
     * Get featured novels
     */
    public function getFeaturedNovels($limit = 6)
    {
        return $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.status', 'published')
                    ->where('novels.is_featured', true)
                    ->groupBy('novels.id')
                    ->orderBy('novels.created_at', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Get latest novels
     */
    public function getLatestNovels($limit = 12)
    {
        return $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.status', 'published')
                    ->groupBy('novels.id')
                    ->orderBy('novels.created_at', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Get popular novels (most viewed)
     */
    public function getPopularNovels($limit = 5)
    {
        return $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.status', 'published')
                    ->groupBy('novels.id')
                    ->orderBy('novels.views', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Get recently updated novels
     */
    public function getRecentlyUpdated($limit = 12, $offset = 0, $status = '')
    {
        $query = $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.status', 'published');

        if ($status === 'completed') {
            $query->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('novels.is_completed', false);
        }

        return $query->groupBy('novels.id')
                    ->orderBy('novels.updated_at', 'DESC')
                    ->limit($limit, $offset)
                    ->find();
    }

    /**
     * Count recently updated novels
     */
    public function getRecentlyUpdatedCount($status = '')
    {
        $query = $this->where('status', 'published');

        if ($status === 'completed') {
            $query->where('is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('is_completed', false);
        }

        return $query->countAllResults();
    }

    /**
     * Get completed novels
     */
    public function getCompleted($limit = 12, $offset = 0, $sort = 'latest')
    {
        $query = $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.status', 'published')
                    ->where('novels.is_completed', true)
                    ->groupBy('novels.id');

        switch ($sort) {
            case 'views':
                $query->orderBy('novels.views', 'DESC');
                break;
            case 'rating':
                $query->orderBy('novels.rating', 'DESC');
                break;
            case 'latest':
            default:
                $query->orderBy('novels.created_at', 'DESC');
                break;
        }

        return $query->limit($limit, $offset)->find();
    }

    /**
     * Count completed novels
     */
    public function getCompletedCount()
    {
        return $this->where('status', 'published')
                    ->where('is_completed', true)
                    ->countAllResults();
    }

    /**
     * Get hot novels
     */
    public function getHotNovels($limit = 12, $offset = 0, $sort = 'views', $status = '')
    {
        $query = $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.status', 'published')
                    ->where('novels.is_hot', true);

        if ($status === 'completed') {
            $query->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('novels.is_completed', false);
        }

        $query->groupBy('novels.id');

        switch ($sort) {
            case 'latest':
                $query->orderBy('novels.created_at', 'DESC');
                break;
            case 'rating':
                $query->orderBy('novels.rating', 'DESC');
                break;
            case 'views':
            default:
                $query->orderBy('novels.views', 'DESC');
                break;
        }

        return $query->limit($limit, $offset)->find();
    }

    /**
     * Count hot novels
     */
    public function getHotNovelsCount($status = '')
    {
        $query = $this->where('status', 'published')
                    ->where('is_hot', true);

        if ($status === 'completed') {
            $query->where('is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('is_completed', false);
        }

        return $query->countAllResults();
    }

    /**
     * Get novels by category
     */
    public function getByCategory($categoryId, $limit = 12, $offset = 0, $sort = 'latest', $status = '')
    {
        $query = $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('novel_categories', 'novel_categories.novel_id = novels.id', 'inner')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novel_categories.category_id', $categoryId)
                    ->where('novels.status', 'published');

        if ($status === 'completed') {
            $query->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('novels.is_completed', false);
        }

        $query->groupBy('novels.id');

        switch ($sort) {
            case 'views':
                $query->orderBy('novels.views', 'DESC');
                break;
            case 'rating':
                $query->orderBy('novels.rating', 'DESC');
                break;
            case 'latest':
            default:
                $query->orderBy('novels.created_at', 'DESC');
                break;
        }

        return $query->limit($limit, $offset)->find();
    }

    /**
     * Count novels by category
     */
    public function getByCategoryCount($categoryId, $status = '')
    {
        $query = $this->join('novel_categories', 'novel_categories.novel_id = novels.id', 'inner')
                    ->where('novel_categories.category_id', $categoryId)
                    ->where('novels.status', 'published');

        if ($status === 'completed') {
            $query->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('novels.is_completed', false);
        }

        return $query->countAllResults();
    }

    /**
     * Get novels by country
     */
    public function getByCountry($country, $limit = 12, $offset = 0, $sort = 'latest', $status = '')
    {
        $query = $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.country', $country)
                    ->where('novels.status', 'published');

        if ($status === 'completed') {
            $query->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('novels.is_completed', false);
        }

        $query->groupBy('novels.id');

        switch ($sort) {
            case 'views':
                $query->orderBy('novels.views', 'DESC');
                break;
            case 'rating':
                $query->orderBy('novels.rating', 'DESC');
                break;
            case 'latest':
            default:
                $query->orderBy('novels.created_at', 'DESC');
                break;
        }

        return $query->limit($limit, $offset)->find();
    }

    /**
     * Count novels by country
     */
    public function getByCountryCount($country, $status = '')
    {
        $query = $this->where('country', $country)
                    ->where('status', 'published');

        if ($status === 'completed') {
            $query->where('is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('is_completed', false);
        }

        return $query->countAllResults();
    }

    /**
     * Get novels by author
     */
    public function getByAuthor($authorId, $limit = 12, $offset = 0, $sort = 'latest', $status = '')
    {
        $query = $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                    ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                    ->join('users', 'users.id = novels.author_id', 'left')
                    ->where('novels.author_id', $authorId)
                    ->where('novels.status', 'published');

        if ($status === 'completed') {
            $query->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('novels.is_completed', false);
        }

        $query->groupBy('novels.id');

        switch ($sort) {
            case 'views':
                $query->orderBy('novels.views', 'DESC');
                break;
            case 'rating':
                $query->orderBy('novels.rating', 'DESC');
                break;
            case 'latest':
            default:
                $query->orderBy('novels.created_at', 'DESC');
                break;
        }

        return $query->limit($limit, $offset)->find();
    }

    /**
     * Count novels by author
     */
    public function getByAuthorCount($authorId, $status = '')
    {
        $query = $this->where('author_id', $authorId)
                    ->where('status', 'published');

        if ($status === 'completed') {
            $query->where('is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('is_completed', false);
        }

        return $query->countAllResults();
    }

    /**
     * Search novels
     */
    public function searchNovels($query, $limit = 12, $offset = 0, $sort = 'latest', $status = '', $category = '')
    {
        $db = \Config\Database::connect();
        $builder = $db->table('novels');

        $builder->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                ->join('users', 'users.id = novels.author_id', 'left')
                ->where('novels.status', 'published')
                ->groupStart()
                    ->like('novels.title', $query)
                    ->orLike('novels.description', $query)
                    ->orLike('users.username', $query)
                ->groupEnd();

        // Apply category filter
        if (!empty($category)) {
            $builder->join('novel_categories', 'novel_categories.novel_id = novels.id')
                    ->join('categories', 'categories.id = novel_categories.category_id')
                    ->where('categories.slug', $category);
        }

        // Apply status filter
        if ($status === 'completed') {
            $builder->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $builder->where('novels.is_completed', false);
        }

        // Group by to avoid duplicates
        $builder->groupBy('novels.id');

        // Apply sort
        switch ($sort) {
            case 'views':
                $builder->orderBy('novels.views', 'DESC');
                break;
            case 'rating':
                $builder->orderBy('novels.rating', 'DESC');
                break;
            case 'chapters':
                $builder->orderBy('latest_chapter', 'DESC');
                break;
            case 'latest':
            default:
                $builder->orderBy('novels.created_at', 'DESC');
                break;
        }

        // Apply limit and offset
        $builder->limit($limit, $offset);

        return $builder->get()->getResultObject();
    }

    /**
     * Count search results
     */
    public function searchNovelsCount($query, $status = '', $category = '')
    {
        $db = \Config\Database::connect();
        $builder = $db->table('novels');

        $builder->where('novels.status', 'published')
                ->groupStart()
                    ->like('novels.title', $query)
                    ->orLike('novels.description', $query)
                    ->orLike('users.username', $query)
                ->groupEnd()
                ->join('users', 'users.id = novels.author_id', 'left');

        // Apply category filter
        if (!empty($category)) {
            $builder->join('novel_categories', 'novel_categories.novel_id = novels.id')
                    ->join('categories', 'categories.id = novel_categories.category_id')
                    ->where('categories.slug', $category);
        }

        // Apply status filter
        if ($status === 'completed') {
            $builder->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $builder->where('novels.is_completed', false);
        }

        return $builder->countAllResults();
    }

    /**
     * Get search suggestions
     */
    public function getSearchSuggestions($query, $limit = 5)
    {
        return $this->select('novels.id, novels.title, novels.slug, novels.cover_image')
                    ->like('novels.title', $query)
                    ->where('novels.status', 'published')
                    ->orderBy('novels.views', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Increment novel views
     */
    public function incrementViews($novelId)
    {
        return $this->set('views', 'views + 1', false)
                    ->where('id', $novelId)
                    ->update();
    }

    /**
     * Get novel ratings count
     */
    public function getRatingsCount($novelId)
    {
        $db = \Config\Database::connect();
        return $db->table('ratings')
                 ->where('novel_id', $novelId)
                 ->countAllResults();
    }

    /**
     * Get novel bookmarks count
     */
    public function getBookmarksCount($novelId)
    {
        $db = \Config\Database::connect();
        return $db->table('bookmarks')
                 ->where('novel_id', $novelId)
                 ->countAllResults();
    }

    /**
     * Get user's rating for a novel
     */
    public function getUserRating($novelId, $userId)
    {
        $db = \Config\Database::connect();
        $result = $db->table('ratings')
                     ->select('rating')
                     ->where('novel_id', $novelId)
                     ->where('user_id', $userId)
                     ->get()
                     ->getRow();

        return $result ? (int)$result->rating : 0;
    }

    /**
     * Check if a novel is bookmarked by user
     */
    public function isBookmarked($novelId, $userId)
    {
        $db = \Config\Database::connect();
        return (bool)$db->table('bookmarks')
                       ->where('novel_id', $novelId)
                       ->where('user_id', $userId)
                       ->countAllResults();
    }

    /**
     * Get user's reading progress
     */
    public function getReadingProgress($novelId, $userId)
    {
        $db = \Config\Database::connect();
        $result = $db->table('reading_progress')
                     ->select('reading_progress.*, chapters.chapter_number')
                     ->join('chapters', 'chapters.id = reading_progress.chapter_id')
                     ->where('reading_progress.novel_id', $novelId)
                     ->where('reading_progress.user_id', $userId)
                     ->get()
                     ->getRow();

        return $result ?? null;
    }

    /**
     * Toggle bookmark
     */
    public function toggleBookmark($novelId, $userId)
    {
        $db = \Config\Database::connect();

        $isBookmarked = $this->isBookmarked($novelId, $userId);

        if ($isBookmarked) {
            // Remove bookmark
            $db->table('bookmarks')
               ->where('novel_id', $novelId)
               ->where('user_id', $userId)
               ->delete();

            return false;
        } else {
            // Add bookmark
            $db->table('bookmarks')
               ->insert([
                   'novel_id' => $novelId,
                   'user_id' => $userId,
                   'created_at' => date('Y-m-d H:i:s')
               ]);

            return true;
        }
    }

    /**
     * Bookmark a novel
     */
    public function bookmarkNovel($novelId, $userId)
    {
        $db = \Config\Database::connect();

        if (!$this->isBookmarked($novelId, $userId)) {
            $db->table('bookmarks')
               ->insert([
                   'novel_id' => $novelId,
                   'user_id' => $userId,
                   'created_at' => date('Y-m-d H:i:s')
               ]);

            return true;
        }

        return true; // Already bookmarked
    }

    /**
     * Rate a novel
     */
    public function rateNovel($novelId, $userId, $rating)
    {
        $db = \Config\Database::connect();

        $existingRating = $db->table('ratings')
                            ->where('novel_id', $novelId)
                            ->where('user_id', $userId)
                            ->get()
                            ->getRow();

        if ($existingRating) {
            // Update rating
            $result = $db->table('ratings')
                        ->where('novel_id', $novelId)
                        ->where('user_id', $userId)
                        ->update([
                            'rating' => $rating,
                            'created_at' => date('Y-m-d H:i:s')
                        ]);
        } else {
            // Add new rating
            $result = $db->table('ratings')
                        ->insert([
                            'novel_id' => $novelId,
                            'user_id' => $userId,
                            'rating' => $rating,
                            'created_at' => date('Y-m-d H:i:s')
                        ]);
        }

        // Update novel rating
        $this->updateNovelRating($novelId);

        return (bool)$result;
    }

    /**
     * Update novel rating
     */
    protected function updateNovelRating($novelId)
    {
        $db = \Config\Database::connect();

        $query = $db->table('ratings')
                    ->selectAvg('rating')
                    ->where('novel_id', $novelId)
                    ->get();

        $result = $query->getRow();

        if ($result && isset($result->rating)) {
            $this->update($novelId, [
                'rating' => round((float)$result->rating, 1)
            ]);
        }
    }

    /**
     * Get similar novels
     */
    public function getSimilarNovels($novelId, $categories, $limit = 6)
    {
        if (empty($categories)) {
            return [];
        }

        $categoryIds = array_column($categories, 'id');

        $db = \Config\Database::connect();
        $builder = $db->table('novels');

        $builder->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name, COUNT(DISTINCT novel_categories.category_id) as category_matches')
                ->join('novel_categories', 'novel_categories.novel_id = novels.id')
                ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                ->join('users', 'users.id = novels.author_id', 'left')
                ->whereIn('novel_categories.category_id', $categoryIds)
                ->where('novels.id !=', $novelId)
                ->where('novels.status', 'published')
                ->groupBy('novels.id')
                ->orderBy('category_matches', 'DESC')
                ->orderBy('novels.rating', 'DESC')
                ->limit($limit);

        return $builder->get()->getResultObject();
    }

    /**
     * Get novel list with filters
     */
    public function getNovelList($limit = 24, $offset = 0, $sort = 'latest', $status = '')
    {
        $query = $this->select('novels.*, COUNT(chapters.id) as latest_chapter, users.username as author_name')
                     ->join('chapters', 'chapters.novel_id = novels.id', 'left')
                     ->join('users', 'users.id = novels.author_id', 'left')
                     ->where('novels.status', 'published');

        if ($status === 'completed') {
            $query->where('novels.is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('novels.is_completed', false);
        }

        $query->groupBy('novels.id');

        switch ($sort) {
            case 'views':
                $query->orderBy('novels.views', 'DESC');
                break;
            case 'rating':
                $query->orderBy('novels.rating', 'DESC');
                break;
            case 'latest':
            default:
                $query->orderBy('novels.created_at', 'DESC');
                break;
        }

        return $query->limit($limit, $offset)->find();
    }

    /**
     * Count novels for listing
     */
    public function getNovelListCount($status = '')
    {
        $query = $this->where('status', 'published');

        if ($status === 'completed') {
            $query->where('is_completed', true);
        } elseif ($status === 'ongoing') {
            $query->where('is_completed', false);
        }

        return $query->countAllResults();
    }
}
