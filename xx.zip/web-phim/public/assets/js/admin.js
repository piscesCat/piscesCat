/**
 * Admin JavaScript functions for web-truyen
 * With dynamic content loading support similar to phimhottt.com
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialize admin UI components
    initAdminUI();

    // Initialize dynamic content loading for admin panel
    initDynamicContentLoading();
});

/**
 * Initialize all admin UI components
 */
function initAdminUI() {
    // Initialize DataTables
    initDataTables();

    // Initialize Summernote Editor
    initSummernoteEditors();

    // Initialize image upload previews
    initImageUploadPreviews();

    // Initialize slug generators
    initSlugGenerators();

    // Initialize confirmation dialogs
    initConfirmationDialogs();

    // Initialize ajax delete buttons
    initAjaxDeleteButtons();

    // Initialize charts
    initializeCharts();

    // Initialize ajax selects
    initAjaxSelects();

    // Initialize bulk actions
    initBulkActions();
}

/**
 * Initialize dynamic content loading via AJAX for admin panel
 */
function initDynamicContentLoading() {
    // Get the main content container
    const contentContainer = document.getElementById('main-content');
    if (!contentContainer) return;

    // Get all internal links that should use AJAX loading
    const internalLinks = document.querySelectorAll('a[href^="' + baseUrl + '/admin"]:not([data-no-ajax]):not([target="_blank"])');

    internalLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Skip if modified click (ctrl, shift, etc.) or form submission
            if (e.ctrlKey || e.shiftKey || e.metaKey || e.defaultPrevented) return;

            // Skip links that require direct navigation (data-no-ajax or within forms)
            if (this.getAttribute('data-no-ajax') === 'true' ||
                this.closest('form') ||
                this.getAttribute('href').includes('logout')) {
                return;
            }

            e.preventDefault();
            const url = this.getAttribute('href');

            // Show loading indicator
            showLoadingIndicator();

            // Load the content
            loadContent(url);

            // Update browser history
            window.history.pushState({url: url}, '', url);

            // Update active state in sidebar
            updateSidebarActiveState(url);
        });
    });

    // Handle back/forward browser navigation
    window.addEventListener('popstate', function(e) {
        if (e.state && e.state.url) {
            showLoadingIndicator();
            loadContent(e.state.url);
            updateSidebarActiveState(e.state.url);
        } else if (window.location.href) {
            showLoadingIndicator();
            loadContent(window.location.href);
            updateSidebarActiveState(window.location.href);
        }
    });

    // Initial state
    window.history.replaceState({url: window.location.href}, '', window.location.href);
}

/**
 * Load content from URL via AJAX
 * @param {string} url - The URL to load
 */
function loadContent(url) {
    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(html => {
        // Parse the HTML string
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');

        // Extract the main content
        const newContent = doc.getElementById('main-content');

        if (newContent) {
            // Update the page content
            document.getElementById('main-content').innerHTML = newContent.innerHTML;

            // Update page title
            document.title = doc.title;

            // Run scripts in the new content
            executeScripts(newContent);

            // Reinitialize components
            initAdminUI();

            // Scroll to top
            window.scrollTo(0, 0);
        } else {
            // Fallback to full page reload if main content container not found
            window.location.href = url;
        }
    })
    .catch(error => {
        console.error('Error loading content:', error);
        // Fallback to traditional navigation on error
        window.location.href = url;
    })
    .finally(() => {
        // Hide loading indicator
        hideLoadingIndicator();
    });
}

/**
 * Update the active state in the sidebar based on the current URL
 * @param {string} url - The current URL
 */
function updateSidebarActiveState(url) {
    // Remove active class from all sidebar links
    const sidebarLinks = document.querySelectorAll('#sidebar .nav-link');
    sidebarLinks.forEach(link => {
        link.classList.remove('active');
    });

    // Determine which sidebar link should be active based on URL
    const urlPath = new URL(url).pathname;
    let activeLink;

    if (urlPath === baseUrl + '/admin') {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin"]');
    } else if (urlPath.includes('/admin/stories')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/stories"]');
    } else if (urlPath.includes('/admin/chapters')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/chapters"]');
    } else if (urlPath.includes('/admin/categories')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/categories"]');
    } else if (urlPath.includes('/admin/users')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/users"]');
    } else if (urlPath.includes('/admin/comments')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/comments"]');
    } else if (urlPath.includes('/admin/reports')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/reports"]');
    } else if (urlPath.includes('/admin/settings')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/settings"]');
    } else if (urlPath.includes('/admin/uploads')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/uploads"]');
    } else if (urlPath.includes('/admin/backups')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/backups"]');
    } else if (urlPath.includes('/admin/logs')) {
        activeLink = document.querySelector('#sidebar .nav-link[href="' + baseUrl + '/admin/logs"]');
    }

    // Add active class to the matching link
    if (activeLink) {
        activeLink.classList.add('active');
    }
}

/**
 * Execute scripts in the loaded content
 * @param {HTMLElement} contentElement - The new content element
 */
function executeScripts(contentElement) {
    const scripts = contentElement.querySelectorAll('script');
    scripts.forEach(script => {
        const newScript = document.createElement('script');

        // Copy all attributes
        Array.from(script.attributes).forEach(attr => {
            newScript.setAttribute(attr.name, attr.value);
        });

        // Copy inline script content
        newScript.textContent = script.textContent;

        // Replace the old script with the new one
        script.parentNode.replaceChild(newScript, script);
    });
}

/**
 * Show loading indicator
 */
function showLoadingIndicator() {
    // Create loading indicator if it doesn't exist
    if (!document.getElementById('ajax-loader')) {
        const loader = document.createElement('div');
        loader.id = 'ajax-loader';
        loader.innerHTML = '<div class="spinner-border text-light" role="status"><span class="visually-hidden">Loading...</span></div>';
        loader.style.position = 'fixed';
        loader.style.top = '50%';
        loader.style.left = '50%';
        loader.style.transform = 'translate(-50%, -50%)';
        loader.style.zIndex = '9999';
        loader.style.display = 'none';
        document.body.appendChild(loader);
    }

    document.getElementById('ajax-loader').style.display = 'block';
}

/**
 * Hide loading indicator
 */
function hideLoadingIndicator() {
    const loader = document.getElementById('ajax-loader');
    if (loader) {
        loader.style.display = 'none';
    }
}

/**
 * Initialize DataTables
 */
function initDataTables() {
    const dataTables = document.querySelectorAll('.datatable');
    if (dataTables.length > 0) {
        dataTables.forEach(table => {
            // Destroy existing DataTable if it exists
            if ($.fn.DataTable.isDataTable(table)) {
                $(table).DataTable().destroy();
            }

            new DataTable(table, {
                responsive: true,
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/vi.json'
                }
            });
        });
    }
}

/**
 * Initialize Summernote Editors
 */
function initSummernoteEditors() {
    const summernoteEditors = document.querySelectorAll('.summernote');
    if (summernoteEditors.length > 0) {
        summernoteEditors.forEach(editor => {
            // Destroy existing instance if it exists
            if ($(editor).data('summernote')) {
                $(editor).summernote('destroy');
            }

            $(editor).summernote({
                height: 300,
                minHeight: 200,
                lang: 'vi-VN',
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'clear']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['table', ['table']],
                    ['insert', ['link', 'picture']],
                    ['view', ['fullscreen', 'codeview', 'help']]
                ],
                callbacks: {
                    onImageUpload: function(files) {
                        uploadSummernoteImage(files[0], editor);
                    }
                }
            });
        });
    }
}

/**
 * Upload image for Summernote
 */
function uploadSummernoteImage(file, editor) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', 'summernote');

    fetch(`${baseUrl}/admin/uploads/upload-image`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            $(editor).summernote('insertImage', data.url, data.filename);
        } else {
            showNotification(data.message || 'Có lỗi xảy ra khi tải lên hình ảnh', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Có lỗi xảy ra khi tải lên hình ảnh', 'error');
    });
}

/**
 * Initialize image upload previews
 */
function initImageUploadPreviews() {
    const imageInputs = document.querySelectorAll('.image-upload-input');
    if (imageInputs.length > 0) {
        imageInputs.forEach(input => {
            input.addEventListener('change', function() {
                const preview = document.querySelector(this.dataset.preview);
                if (preview && this.files && this.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                    }
                    reader.readAsDataURL(this.files[0]);
                }
            });
        });
    }
}

/**
 * Initialize slug generators
 */
function initSlugGenerators() {
    const titleInputs = document.querySelectorAll('[data-generate-slug]');
    if (titleInputs.length > 0) {
        titleInputs.forEach(input => {
            input.addEventListener('input', function() {
                const targetId = this.dataset.generateSlug;
                const slugInput = document.getElementById(targetId);

                if (slugInput && !slugInput.value.trim()) {
                    const slug = createSlug(this.value);
                    slugInput.value = slug;
                }
            });
        });
    }
}

/**
 * Create slug from string
 */
function createSlug(text) {
    // Convert Vietnamese characters to ASCII
    const from = 'àáäâãåăæąçćčđďèéěėëêęğǵḧìíïîįłḿǹńňñòóöôœøṕŕřßşśšșťțùúüûǘůűūųẃẍÿýźžż·/_,:;';
    const to = 'aaaaaaaaacccddeeeeeeeggghiiiiilmnnnnooooooprrsssssttuuuuuuuuuwxyyzzz------';

    // Replace Vietnamese characters
    let slug = text.toLowerCase().trim();
    for (let i = 0, l = from.length; i < l; i++) {
        slug = slug.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
    }

    // Remove invalid chars
    slug = slug.replace(/[^a-z0-9 -]/g, '')
        // Collapse whitespace and replace by -
        .replace(/\s+/g, '-')
        // Collapse dashes
        .replace(/-+/g, '-');

    return slug;
}

/**
 * Initialize confirmation dialogs
 */
function initConfirmationDialogs() {
    const confirmButtons = document.querySelectorAll('[data-confirm]');
    if (confirmButtons.length > 0) {
        confirmButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm(this.dataset.confirm)) {
                    e.preventDefault();
                    return false;
                }
            });
        });
    }
}

/**
 * Initialize AJAX delete buttons
 */
function initAjaxDeleteButtons() {
    const ajaxDeleteButtons = document.querySelectorAll('.ajax-delete');
    if (ajaxDeleteButtons.length > 0) {
        ajaxDeleteButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                const url = this.href || this.dataset.url;
                const confirmMessage = this.dataset.confirm || 'Bạn có chắc chắn muốn xóa?';
                const itemId = this.dataset.id;
                const tableRow = this.closest('tr');

                if (!confirm(confirmMessage)) {
                    return false;
                }

                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({ id: itemId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (tableRow) {
                            tableRow.style.backgroundColor = '#f8d7da';
                            setTimeout(() => {
                                tableRow.style.display = 'none';
                            }, 500);
                        }

                        // Show success message
                        showNotification(data.message || 'Xóa thành công', 'success');
                    } else {
                        showNotification(data.message || 'Có lỗi xảy ra', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Có lỗi xảy ra, vui lòng thử lại sau', 'error');
                });
            });
        });
    }
}

/**
 * Show notification
 */
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} notification-toast`;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.style.minWidth = '300px';
    notification.style.boxShadow = '0 0.5rem 1rem rgba(0, 0, 0, 0.15)';
    notification.innerHTML = `
        <div class="d-flex justify-content-between align-items-center">
            <div>${message}</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;

    document.body.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.classList.add('fade');
        setTimeout(() => {
            notification.remove();
        }, 500);
    }, 5000);
}

/**
 * Initialize charts if they exist
 */
function initializeCharts() {
    // Visitors chart
    const visitorsChartCanvas = document.getElementById('visitorsChart');
    if (visitorsChartCanvas) {
        fetch(`${baseUrl}/admin/dashboard/stats`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const days = getDaysArray(7);

                    // Destroy existing chart if it exists
                    if (Chart.getChart(visitorsChartCanvas)) {
                        Chart.getChart(visitorsChartCanvas).destroy();
                    }

                    new Chart(visitorsChartCanvas, {
                        type: 'line',
                        data: {
                            labels: days,
                            datasets: [{
                                label: 'Lượt xem',
                                data: data.visits_data,
                                borderColor: '#3abfcb',
                                backgroundColor: 'rgba(58, 191, 203, 0.1)',
                                tension: 0.3,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: false
                                },
                                tooltip: {
                                    mode: 'index',
                                    intersect: false
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        color: '#b8b8b8'
                                    },
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.05)'
                                    }
                                },
                                x: {
                                    ticks: {
                                        color: '#b8b8b8'
                                    },
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.05)'
                                    }
                                }
                            }
                        }
                    });
                }
            })
            .catch(error => console.error('Error fetching chart data:', error));
    }

    // Top stories chart
    const topStoriesChartCanvas = document.getElementById('topStoriesChart');
    if (topStoriesChartCanvas) {
        fetch(`${baseUrl}/admin/dashboard/top-stories`)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.stories.length > 0) {
                    const titles = data.stories.map(story => story.title);
                    const views = data.stories.map(story => story.views);

                    // Destroy existing chart if it exists
                    if (Chart.getChart(topStoriesChartCanvas)) {
                        Chart.getChart(topStoriesChartCanvas).destroy();
                    }

                    new Chart(topStoriesChartCanvas, {
                        type: 'bar',
                        data: {
                            labels: titles,
                            datasets: [{
                                label: 'Lượt xem',
                                data: views,
                                backgroundColor: 'rgba(186, 144, 91, 0.7)',
                                borderColor: '#ba905b',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            indexAxis: 'y',
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: false
                                }
                            },
                            scales: {
                                y: {
                                    ticks: {
                                        color: '#b8b8b8'
                                    },
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.05)'
                                    }
                                },
                                x: {
                                    beginAtZero: true,
                                    ticks: {
                                        color: '#b8b8b8'
                                    },
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.05)'
                                    }
                                }
                            }
                        }
                    });
                }
            })
            .catch(error => console.error('Error fetching chart data:', error));
    }
}

/**
 * Get array of dates for last 7 days
 */
function getDaysArray(numDays) {
    const result = [];
    for (let i = numDays - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        result.push(formatDate(d));
    }
    return result;
}

/**
 * Format date to DD/MM
 */
function formatDate(date) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    return `${day}/${month}`;
}

/**
 * Initialize AJAX select dropdowns
 */
function initAjaxSelects() {
    const ajaxSelects = document.querySelectorAll('.ajax-select');
    if (ajaxSelects.length > 0 && typeof $.fn.select2 !== 'undefined') {
        ajaxSelects.forEach(select => {
            // Destroy existing instance if it exists
            if ($(select).data('select2')) {
                $(select).select2('destroy');
            }

            const url = select.dataset.url;
            const placeholder = select.dataset.placeholder || 'Tìm kiếm...';

            $(select).select2({
                theme: 'bootstrap-5',
                width: '100%',
                placeholder: placeholder,
                ajax: {
                    url: url,
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        return {
                            q: params.term,
                            page: params.page || 1
                        };
                    },
                    processResults: function(data, params) {
                        params.page = params.page || 1;

                        return {
                            results: data.results,
                            pagination: {
                                more: data.pagination.more
                            }
                        };
                    },
                    cache: true
                },
                templateResult: formatResult,
                templateSelection: formatSelection,
                escapeMarkup: function(markup) {
                    return markup;
                }
            });
        });
    }
}

/**
 * Format the result for select2
 */
function formatResult(data) {
    if (data.loading) return data.text;

    let markup = `<div class="select2-result d-flex align-items-center">`;

    if (data.image) {
        markup += `<img src="${data.image}" class="select2-result-image me-2" width="40" height="40" />`;
    }

    markup += `<div class="select2-result-text">
                    <div class="select2-result-title">${data.text}</div>`;

    if (data.description) {
        markup += `<div class="select2-result-description small text-muted">${data.description}</div>`;
    }

    markup += `</div></div>`;

    return markup;
}

/**
 * Format the selection for select2
 */
function formatSelection(data) {
    return data.text || data.id;
}

/**
 * Initialize bulk actions
 */
function initBulkActions() {
    const bulkForm = document.getElementById('bulkActionForm');
    if (bulkForm) {
        bulkForm.addEventListener('submit', function(e) {
            const action = document.getElementById('bulkAction').value;
            const checkboxes = document.querySelectorAll('input[name="bulk_items[]"]:checked');

            if (action === '') {
                e.preventDefault();
                showNotification('Vui lòng chọn một hành động', 'error');
                return false;
            }

            if (checkboxes.length === 0) {
                e.preventDefault();
                showNotification('Vui lòng chọn ít nhất một mục', 'error');
                return false;
            }

            if (action === 'delete' && !confirm('Bạn có chắc chắn muốn xóa các mục đã chọn?')) {
                e.preventDefault();
                return false;
            }
        });

        // Toggle all checkboxes
        const selectAllCheckbox = document.getElementById('selectAll');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('input[name="bulk_items[]"]');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
        }
    }
}
