/**
 * Web Truyen - Dynamic Content Loading
 * Similar to phimhottt.com implementation
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dynamic content loading
    initDynamicContentLoading();

    // Initialize other features
    initSearchAutoComplete();
    initBookmarkToggle();
    initLazyLoading();
    initTooltips();
});

/**
 * Initialize dynamic content loading via AJAX
 * This mimics phimhottt.com's approach to loading pages without full refreshes
 */
function initDynamicContentLoading() {
    // Get the main content container
    const contentContainer = document.getElementById('main-content');
    if (!contentContainer) return;

    // Get all internal links that should use AJAX loading
    const internalLinks = document.querySelectorAll('a[href^="' + baseUrl + '"]:not([data-no-ajax]):not([target="_blank"])');

    internalLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Skip if modified click (ctrl, shift, etc.)
            if (e.ctrlKey || e.shiftKey || e.metaKey || e.defaultPrevented) return;

            e.preventDefault();
            const url = this.getAttribute('href');

            // Show loading indicator
            showLoadingIndicator();

            // Load the content
            loadContent(url);

            // Update browser history
            window.history.pushState({url: url}, '', url);
        });
    });

    // Handle back/forward browser navigation
    window.addEventListener('popstate', function(e) {
        if (e.state && e.state.url) {
            showLoadingIndicator();
            loadContent(e.state.url);
        } else if (window.location.href) {
            showLoadingIndicator();
            loadContent(window.location.href);
        }
    });

    // Initial state
    window.history.replaceState({url: window.location.href}, '', window.location.href);
}

/**
 * Load content from URL via AJAX
 * @param {string} url - The URL to load
 */
function loadContent(url) {
    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(html => {
        // Parse the HTML string
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');

        // Extract the main content
        const newContent = doc.getElementById('main-content');

        if (newContent) {
            // Update the page content
            document.getElementById('main-content').innerHTML = newContent.innerHTML;

            // Update page title
            document.title = doc.title;

            // Run scripts in the new content
            executeScripts(newContent);

            // Reinitialize components
            initLazyLoading();
            initTooltips();
            initDynamicContentLoading(); // Reinitialize for new links

            // Scroll to top
            window.scrollTo(0, 0);
        } else {
            // Fallback to full page reload if main content container not found
            window.location.href = url;
        }
    })
    .catch(error => {
        console.error('Error loading content:', error);
        // Fallback to traditional navigation on error
        window.location.href = url;
    })
    .finally(() => {
        // Hide loading indicator
        hideLoadingIndicator();
    });
}

/**
 * Execute scripts in the loaded content
 * @param {HTMLElement} contentElement - The new content element
 */
function executeScripts(contentElement) {
    const scripts = contentElement.querySelectorAll('script');
    scripts.forEach(script => {
        const newScript = document.createElement('script');

        // Copy all attributes
        Array.from(script.attributes).forEach(attr => {
            newScript.setAttribute(attr.name, attr.value);
        });

        // Copy inline script content
        newScript.textContent = script.textContent;

        // Replace the old script with the new one
        script.parentNode.replaceChild(newScript, script);
    });
}

/**
 * Show loading indicator
 */
function showLoadingIndicator() {
    // Create loading indicator if it doesn't exist
    if (!document.getElementById('ajax-loader')) {
        const loader = document.createElement('div');
        loader.id = 'ajax-loader';
        loader.innerHTML = '<div class="spinner-border text-light" role="status"><span class="visually-hidden">Loading...</span></div>';
        loader.style.position = 'fixed';
        loader.style.top = '50%';
        loader.style.left = '50%';
        loader.style.transform = 'translate(-50%, -50%)';
        loader.style.zIndex = '9999';
        loader.style.display = 'none';
        document.body.appendChild(loader);
    }

    document.getElementById('ajax-loader').style.display = 'block';
}

/**
 * Hide loading indicator
 */
function hideLoadingIndicator() {
    const loader = document.getElementById('ajax-loader');
    if (loader) {
        loader.style.display = 'none';
    }
}

/**
 * Initialize search autocomplete functionality
 */
function initSearchAutoComplete() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;

    let typingTimer;
    const doneTypingInterval = 300; // ms

    searchInput.addEventListener('input', function() {
        clearTimeout(typingTimer);
        if (searchInput.value) {
            typingTimer = setTimeout(fetchSearchSuggestions, doneTypingInterval);
        } else {
            document.getElementById('search-suggestions')?.classList.add('d-none');
        }
    });

    function fetchSearchSuggestions() {
        if (searchInput.value.length < 2) return;

        fetch(`${baseUrl}/search/suggestions?q=${encodeURIComponent(searchInput.value)}`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            updateSearchSuggestions(data.results);
        })
        .catch(error => {
            console.error('Error fetching search suggestions:', error);
        });
    }

    function updateSearchSuggestions(results) {
        let suggestionsContainer = document.getElementById('search-suggestions');

        if (!suggestionsContainer) {
            suggestionsContainer = document.createElement('div');
            suggestionsContainer.id = 'search-suggestions';
            suggestionsContainer.className = 'position-absolute bg-dark border border-secondary rounded-bottom w-100 shadow-lg';
            suggestionsContainer.style.zIndex = '1000';
            searchInput.parentNode.appendChild(suggestionsContainer);
        }

        if (results && results.length > 0) {
            let html = '<div class="p-2">';
            results.forEach(item => {
                html += `
                <a href="${baseUrl}/story/${item.slug}" class="d-flex align-items-center text-decoration-none text-light p-2 rounded hover-bg-secondary mb-1">
                    <img src="${item.cover_image}" class="rounded" width="40" height="60" alt="${item.title}">
                    <div class="ms-2">
                        <div class="fw-bold">${item.title}</div>
                        <small class="text-muted">${item.author} • ${item.latest_chapter} chương</small>
                    </div>
                </a>`;
            });
            html += `<a href="${baseUrl}/tim-kiem?q=${encodeURIComponent(searchInput.value)}" class="d-block text-center text-info p-2">Xem tất cả kết quả</a>`;
            html += '</div>';

            suggestionsContainer.innerHTML = html;
            suggestionsContainer.classList.remove('d-none');
        } else {
            suggestionsContainer.innerHTML = '<div class="p-3 text-center text-muted">Không tìm thấy kết quả</div>';
            suggestionsContainer.classList.remove('d-none');
        }
    }

    // Hide suggestions when clicking outside
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !document.getElementById('search-suggestions')?.contains(e.target)) {
            document.getElementById('search-suggestions')?.classList.add('d-none');
        }
    });
}

/**
 * Initialize bookmark toggle functionality
 */
function initBookmarkToggle() {
    const bookmarkButtons = document.querySelectorAll('.bookmark-btn');

    bookmarkButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const storyId = this.dataset.storyId;
            if (!storyId) return;

            // Check if user is logged in
            if (!userId) {
                window.location.href = `${baseUrl}/login?redirect=${encodeURIComponent(window.location.href)}`;
                return;
            }

            fetch(`${baseUrl}/bookmarks/toggle`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    story_id: storyId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Toggle bookmark icon
                    const icon = this.querySelector('i');
                    if (data.bookmarked) {
                        icon.classList.remove('far');
                        icon.classList.add('fas');
                        this.setAttribute('title', 'Xóa khỏi danh sách đọc');
                    } else {
                        icon.classList.remove('fas');
                        icon.classList.add('far');
                        this.setAttribute('title', 'Thêm vào danh sách đọc');
                    }

                    // Update tooltip if Bootstrap tooltips are initialized
                    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
                        const tooltip = bootstrap.Tooltip.getInstance(this);
                        if (tooltip) {
                            tooltip.dispose();
                            new bootstrap.Tooltip(this);
                        }
                    }

                    // Show flash message
                    showFlashMessage(data.message, 'success');
                } else {
                    showFlashMessage(data.message || 'Đã xảy ra lỗi.', 'error');
                }
            })
            .catch(error => {
                console.error('Error toggling bookmark:', error);
                showFlashMessage('Đã xảy ra lỗi khi cập nhật danh sách đọc.', 'error');
            });
        });
    });
}

/**
 * Initialize lazy loading for images
 */
function initLazyLoading() {
    const lazyImages = document.querySelectorAll('img[data-src]');

    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const image = entry.target;
                    image.src = image.dataset.src;
                    image.removeAttribute('data-src');
                    imageObserver.unobserve(image);
                }
            });
        });

        lazyImages.forEach(function(image) {
            imageObserver.observe(image);
        });
    } else {
        // Fallback for browsers that don't support IntersectionObserver
        lazyImages.forEach(function(image) {
            image.src = image.dataset.src;
            image.removeAttribute('data-src');
        });
    }
}

/**
 * Initialize Bootstrap tooltips
 */
function initTooltips() {
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(tooltip => {
            new bootstrap.Tooltip(tooltip);
        });
    }
}

/**
 * Show flash message
 * @param {string} message - The message to display
 * @param {string} type - Message type (success, error, warning, info)
 */
function showFlashMessage(message, type = 'info') {
    const alertClass = {
        success: 'alert-success',
        error: 'alert-danger',
        warning: 'alert-warning',
        info: 'alert-info'
    }[type];

    const alertHtml = `
    <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>`;

    // Create flash container if it doesn't exist
    let flashContainer = document.getElementById('flash-messages');
    if (!flashContainer) {
        flashContainer = document.createElement('div');
        flashContainer.id = 'flash-messages';
        flashContainer.className = 'position-fixed top-0 end-0 p-3';
        flashContainer.style.zIndex = '1050';
        document.body.appendChild(flashContainer);
    }

    // Add the alert to the container
    const alertElement = document.createElement('div');
    alertElement.innerHTML = alertHtml;
    flashContainer.appendChild(alertElement.firstElementChild);

    // Automatically remove the alert after 5 seconds
    setTimeout(() => {
        const alert = flashContainer.querySelector('.alert');
        if (alert) {
            alert.classList.remove('show');
            setTimeout(() => alert.remove(), 300);
        }
    }, 5000);
}
