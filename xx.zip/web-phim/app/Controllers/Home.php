<?php
// app/Controllers/Home.php
namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        // Redirect to installation if not installed
        if (!$this->isInstalled) {
            return redirect()->to(base_url('install'));
        }

        // Get featured stories
        $storyModel = new \App\Models\StoryModel();
        $featuredStories = $storyModel->getFeatured(6);

        // Get latest stories
        $latestStories = $storyModel->getLatest(12);

        // Get popular stories
        $popularStories = $storyModel->getPopular(5);

        // Get updated stories
        $updatedStories = $storyModel->getRecentlyUpdated(6);

        // Get top authors
        $userModel = new \App\Models\UserModel();
        $db = \Config\Database::connect();
        $query = $db->table('users')
                    ->select('users.id, users.username, users.avatar, COUNT(stories.id) as story_count')
                    ->join('stories', 'stories.author_id = users.id')
                    ->where('stories.status', 'published')
                    ->groupBy('users.id')
                    ->orderBy('story_count', 'DESC')
                    ->limit(5)
                    ->get();
        $topAuthors = $query->getResultArray();

        $data = [
            'title' => 'Trang chủ',
            'featured_stories' => $featuredStories,
            'latest_stories' => $latestStories,
            'popular_stories' => $popularStories,
            'updated_stories' => $updatedStories,
            'top_authors' => $topAuthors
        ];

        return $this->renderView('home.html', $data);
    }
}
