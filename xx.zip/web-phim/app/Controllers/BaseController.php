// app/Controllers/BaseController.php
namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;
use Psr\Log\LoggerInterface;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 */
abstract class BaseController extends Controller
{
    /**
     * Instance of the main Request object.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;

    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers = ['url', 'form', 'text', 'date', 'cookie'];

    /**
     * Session instance
     */
    protected $session;

    /**
     * User model instance
     */
    protected $userModel;

    /**
     * Current logged in user
     */
    protected $currentUser;

    /**
     * Database instance
     */
    protected $db;

    /**
     * Is the system installed
     */
    protected $isInstalled = false;

    /**
     * Constructor.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Initialize database
        $this->db = \Config\Database::connect();

        // Initialize session
        $this->session = Services::session();

        // Check if system is installed
        $this->isInstalled = file_exists(ROOTPATH . 'installed.txt');

        // Get current user from session
        $this->loadCurrentUser();

        // Share common data with all views
        $this->shareCommonData();
    }

    /**
     * Load current user from session
     */
    protected function loadCurrentUser()
    {
        if ($this->isInstalled && $this->session->has('user_id')) {
            $this->userModel = new \App\Models\UserModel();
            $this->currentUser = $this->userModel->find($this->session->get('user_id'));
        }
    }

    /**
     * Share common data with all views
     */
    protected function shareCommonData()
    {
        // Common data for all views
        if ($this->isInstalled) {
            // Load categories
            $categoryModel = new \App\Models\CategoryModel();
            $categories = $categoryModel->findAll();

            // Get site settings
            $settings = $this->getSettings();

            // Share data with views
            $this->viewData = [
                'current_user' => $this->currentUser,
                'categories' => $categories,
                'settings' => $settings,
                'current_url' => current_url(),
                'is_installed' => $this->isInstalled
            ];
        } else {
            // Basic data for installation
            $this->viewData = [
                'current_url' => current_url(),
                'is_installed' => $this->isInstalled
            ];
        }
    }

    /**
     * Get settings from database
     */
    protected function getSettings()
    {
        if (!$this->isInstalled) {
            return [
                'site_name' => 'Web Truyện',
                'site_description' => 'Đọc truyện online, cập nhật nhiều truyện hay và mới nhất.'
            ];
        }

        try {
            // Check if settings table exists
            $settingsTableExists = $this->db->tableExists('settings');
            if (!$settingsTableExists) {
                return [
                    'site_name' => 'Web Truyện',
                    'site_description' => 'Đọc truyện online, cập nhật nhiều truyện hay và mới nhất.'
                ];
            }

            // Get settings from database
            $query = $this->db->table('settings')->get();
            $settings = [];

            foreach ($query->getResult() as $row) {
                $settings[$row->name] = $row->value;
            }

            return $settings;
        } catch (\Exception $e) {
            log_message('error', 'Error loading settings: ' . $e->getMessage());
            return [
                'site_name' => 'Web Truyện',
                'site_description' => 'Đọc truyện online, cập nhật nhiều truyện hay và mới nhất.'
            ];
        }
    }

    /**
     * Render a view with common data
     */
    protected function renderView(string $view, array $data = [])
    {
        // Merge common data with view data
        $mergedData = array_merge($this->viewData, $data);

        // Check if this is an AJAX request
        $isAjaxRequest = $this->request->isAJAX();

        // For AJAX requests, only return the view content without the layout
        if ($isAjaxRequest) {
            // If it's an AJAX request and the view includes a layout,
            // we need to set a flag to prevent layout rendering
            $mergedData['ajax_request'] = true;

            // Render the view
            return view($view, $mergedData);
        }

        // For normal requests, render with layout as usual
        return view($view, $mergedData);
    }

    /**
     * Check if user is logged in
     */
    protected function isLoggedIn()
    {
        return !empty($this->currentUser);
    }

    /**
     * Check if user is admin
     */
    protected function isAdmin()
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser->role === 'admin';
    }

    /**
     * Redirect to login page if not logged in
     */
    protected function requireLogin()
    {
        if (!$this->isLoggedIn()) {
            $this->session->setFlashdata('error', 'Vui lòng đăng nhập để tiếp tục.');
            return redirect()->to(base_url('login?redirect=' . current_url()));
        }

        return true;
    }

    /**
     * Redirect to home page if not admin
     */
    protected function requireAdmin()
    {
        if (!$this->isAdmin()) {
            $this->session->setFlashdata('error', 'Bạn không có quyền truy cập trang này.');
            return redirect()->to(base_url());
        }

        return true;
    }

    /**
     * Redirect to installation if not installed
     */
    protected function requireInstalled()
    {
        if (!$this->isInstalled) {
            return redirect()->to(base_url('install'));
        }

        return true;
    }

    /**
     * Format date to human readable
     */
    protected function formatDate($date, $format = 'd/m/Y H:i')
    {
        if (empty($date)) {
            return '';
        }

        return date($format, strtotime($date));
    }

    /**
     * Calculate time ago from a date
     */
    protected function timeAgo($datetime, $full = false)
    {
        $now = new \DateTime;
        $ago = new \DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = [
            'y' => 'năm',
            'm' => 'tháng',
            'w' => 'tuần',
            'd' => 'ngày',
            'h' => 'giờ',
            'i' => 'phút',
            's' => 'giây',
        ];

        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? '' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' trước' : 'vừa xong';
    }
}
