<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class StoryManager extends BaseController
{
    protected $storyModel;
    protected $userModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->storyModel = new \App\Models\StoryModel();
        $this->userModel = new \App\Models\UserModel();
        $this->categoryModel = new \App\Models\CategoryModel();
    }

    public function index()
    {
        // Set current page for navigation highlighting
        // Remove Twig references
        $stories = $this->storyModel
                     ->select('stories.*, users.username as author_name')
                     ->join('users', 'users.id = stories.author_id')
                     ->orderBy('stories.created_at', 'DESC')
                     ->findAll();

        return view('admin/story/index.html', [
            'stories' => $stories
        ]);
    }

    public function new()
    {
        // Set current page for navigation highlighting
        // Remove Twig references
        $users = $this->userModel->findAll();
        $categories = $this->categoryModel->findAll();

        return view('admin/story/create.html', [
            'users' => $users,
            'categories' => $categories
        ]);
    }

    public function create()
    {
        // Validate form input
        $rules = [
            'title' => 'required|min_length[3]|max_length[200]',
            'slug' => 'required|alpha_dash|min_length[3]|max_length[200]|is_unique[stories.slug]',
            'description' => 'required',
            'author_id' => 'required|integer',
            'status' => 'required|in_list[draft,published,completed]',
            'categories' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Handle image upload
        $coverImage = $this->handleCoverImageUpload();

        // Prepare data
        $data = [
            'title' => $this->request->getPost('title'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description'),
            'author_id' => $this->request->getPost('author_id'),
            'status' => $this->request->getPost('status'),
            'cover_image' => $coverImage,
            'views' => 0,
            'rating' => 0
        ];

        // Insert record
        $db = \Config\Database::connect();
        $db->transStart();

        $storyId = $this->storyModel->insert($data);

        // Insert categories
        $categories = $this->request->getPost('categories');
        foreach ($categories as $categoryId) {
            $db->table('story_categories')->insert([
                'story_id' => $storyId,
                'category_id' => $categoryId
            ]);
        }

        // Add activity log
        $this->logActivity('created_story', [
            'target_type' => 'story',
            'target_id' => $storyId,
            'target_title' => $data['title'],
            'target_slug' => $data['slug']
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->withInput()->with('error', 'Đã xảy ra lỗi khi thêm truyện.');
        }

        return redirect()->to('/admin/stories')->with('success', 'Truyện đã được thêm thành công.');
    }

    public function edit($id)
    {
        // Set current page for navigation highlighting
        // Remove Twig references
        $story = $this->storyModel->find($id);

        if (!$story) {
            return redirect()->to('/admin/stories')->with('error', 'Truyện không tồn tại.');
        }

        $users = $this->userModel->findAll();
        $categories = $this->categoryModel->findAll();

        // Get selected categories
        $db = \Config\Database::connect();
        $selectedCategories = $db->table('story_categories')
                                 ->where('story_id', $id)
                                 ->get()
                                 ->getResultArray();

        $selectedCategoryIds = array_column($selectedCategories, 'category_id');

        return view('admin/story/edit.html', [
            'story' => $story,
            'users' => $users,
            'categories' => $categories,
            'selected_categories' => $selectedCategoryIds
        ]);
    }

    public function update($id)
    {
        // Validate form input
        $rules = [
            'title' => 'required|min_length[3]|max_length[200]',
            'slug' => "required|alpha_dash|min_length[3]|max_length[200]|is_unique[stories.slug,id,$id]",
            'description' => 'required',
            'author_id' => 'required|integer',
            'status' => 'required|in_list[draft,published,completed]',
            'categories' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $story = $this->storyModel->find($id);
        if (!$story) {
            return redirect()->to('/admin/stories')->with('error', 'Truyện không tồn tại.');
        }

        // Handle image upload
        $coverImage = $this->handleCoverImageUpload($story['cover_image']);

        // Prepare data
        $data = [
            'title' => $this->request->getPost('title'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description'),
            'author_id' => $this->request->getPost('author_id'),
            'status' => $this->request->getPost('status'),
        ];

        // Only update cover image if a new one was uploaded
        if ($coverImage) {
            $data['cover_image'] = $coverImage;
        }

        // Update record
        $db = \Config\Database::connect();
        $db->transStart();

        $this->storyModel->update($id, $data);

        // Update categories
        $db->table('story_categories')->where('story_id', $id)->delete();

        $categories = $this->request->getPost('categories');
        foreach ($categories as $categoryId) {
            $db->table('story_categories')->insert([
                'story_id' => $id,
                'category_id' => $categoryId
            ]);
        }

        // Add activity log
        $this->logActivity('updated_story', [
            'target_type' => 'story',
            'target_id' => $id,
            'target_title' => $data['title'],
            'target_slug' => $data['slug']
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->withInput()->with('error', 'Đã xảy ra lỗi khi cập nhật truyện.');
        }

        return redirect()->to('/admin/stories')->with('success', 'Truyện đã được cập nhật thành công.');
    }

    public function delete($id)
    {
        $story = $this->storyModel->find($id);

        if (!$story) {
            return redirect()->to('/admin/stories')->with('error', 'Truyện không tồn tại.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        // Delete story categories
        $db->table('story_categories')->where('story_id', $id)->delete();

        // Delete chapters
        $db->table('chapters')->where('story_id', $id)->delete();

        // Delete bookmarks
        $db->table('bookmarks')->where('story_id', $id)->delete();

        // Delete reading progress
        $db->table('reading_progress')->where('story_id', $id)->delete();

        // Delete ratings
        $db->table('ratings')->where('story_id', $id)->delete();

        // Delete comments
        $db->table('comments')->where('story_id', $id)->delete();

        // Delete the story
        $this->storyModel->delete($id);

        // Add activity log
        $this->logActivity('deleted_story', [
            'target_type' => 'story',
            'target_id' => $id,
            'target_title' => $story['title'],
            'target_slug' => $story['slug']
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->with('error', 'Đã xảy ra lỗi khi xóa truyện.');
        }

        return redirect()->to('/admin/stories')->with('success', 'Truyện đã được xóa thành công.');
    }

    /**
     * AJAX Methods
     */

    public function ajaxList()
    {
        $stories = $this->storyModel
                     ->select('stories.*, users.username as author_name')
                     ->join('users', 'users.id = stories.author_id')
                     ->orderBy('stories.created_at', 'DESC')
                     ->findAll();

        return $this->response->setJSON([
            'success' => true,
            'data' => $stories
        ]);
    }

    public function ajaxSave()
    {
        $id = $this->request->getPost('id');
        $data = [
            'title' => $this->request->getPost('title'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description'),
            'status' => $this->request->getPost('status')
        ];

        if ($id) {
            // Update
            $this->storyModel->update($id, $data);
            $message = 'Truyện đã được cập nhật thành công.';
        } else {
            // Create
            $data['author_id'] = $this->session->get('user_id');
            $data['views'] = 0;
            $data['rating'] = 0;
            $id = $this->storyModel->insert($data);
            $message = 'Truyện đã được thêm thành công.';
        }

        // Add activity log
        $action = $id ? 'updated_story' : 'created_story';
        $this->logActivity($action, [
            'target_type' => 'story',
            'target_id' => $id,
            'target_title' => $data['title'],
            'target_slug' => $data['slug']
        ]);

        return $this->response->setJSON([
            'success' => true,
            'message' => $message,
            'id' => $id
        ]);
    }

    public function ajaxDelete()
    {
        $id = $this->request->getPost('id');

        $story = $this->storyModel->find($id);

        if (!$story) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Truyện không tồn tại.'
            ]);
        }

        $db = \Config\Database::connect();
        $db->transStart();

        // Delete story categories
        $db->table('story_categories')->where('story_id', $id)->delete();

        // Delete chapters
        $db->table('chapters')->where('story_id', $id)->delete();

        // Delete bookmarks
        $db->table('bookmarks')->where('story_id', $id)->delete();

        // Delete reading progress
        $db->table('reading_progress')->where('story_id', $id)->delete();

        // Delete ratings
        $db->table('ratings')->where('story_id', $id)->delete();

        // Delete comments
        $db->table('comments')->where('story_id', $id)->delete();

        // Delete the story
        $this->storyModel->delete($id);

        // Add activity log
        $this->logActivity('deleted_story', [
            'target_type' => 'story',
            'target_id' => $id,
            'target_title' => $story['title'],
            'target_slug' => $story['slug']
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Đã xảy ra lỗi khi xóa truyện.'
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Truyện đã được xóa thành công.'
        ]);
    }

    public function generateSlug()
    {
        $title = $this->request->getPost('title');
        $slug = url_title($title, '-', true);

        // Check if slug exists
        $existingStory = $this->storyModel->where('slug', $slug)->first();

        if ($existingStory) {
            // Add a random string to make unique
            $slug .= '-' . substr(uniqid(), -5);
        }

        return $this->response->setJSON([
            'success' => true,
            'slug' => $slug
        ]);
    }

    /**
     * Helper Methods
     */

    private function handleCoverImageUpload($currentImage = null)
    {
        $file = $this->request->getFile('cover_image');

        // If no file was uploaded and we have a current image, keep using it
        if (!$file || !$file->isValid()) {
            return $currentImage;
        }

        // Generate a random name for the file
        $newName = $file->getRandomName();

        // Move the file to the public/uploads/covers directory
        $file->move(ROOTPATH . 'public/uploads/covers', $newName);

        // Return the path relative to base URL
        return '/uploads/covers/' . $newName;
    }

    private function logActivity($action, $details = [])
    {
        $db = \Config\Database::connect();

        $data = [
            'user_id' => $this->session->get('user_id'),
            'action' => $action,
            'details' => json_encode($details),
            'created_at' => date('Y-m-d H:i:s')
        ];

        $db->table('activities')->insert($data);
    }
}
