<?php
namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table = 'categories';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = ['name', 'slug', 'description', 'parent_id'];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'name' => 'required|min_length[2]|max_length[50]',
        'slug' => 'required|alpha_dash|min_length[2]|max_length[50]|is_unique[categories.slug,id,{id}]',
    ];

    public function getCategoriesWithCount()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('categories')
                      ->select('categories.*, COUNT(story_categories.story_id) as story_count')
                      ->join('story_categories', 'story_categories.category_id = categories.id', 'left')
                      ->join('stories', 'stories.id = story_categories.story_id AND stories.status = "published"', 'left')
                      ->groupBy('categories.id')
                      ->orderBy('name', 'ASC');

        return $builder->get()->getResultArray();
    }

    public function getCategoryBySlug($slug)
    {
        return $this->where('slug', $slug)->first();
    }

    public function getChildCategories($parentId)
    {
        return $this->where('parent_id', $parentId)->findAll();
    }

    public function getSubCategoriesWithCount($parentId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('categories')
                      ->select('categories.*, COUNT(story_categories.story_id) as story_count')
                      ->join('story_categories', 'story_categories.category_id = categories.id', 'left')
                      ->join('stories', 'stories.id = story_categories.story_id AND stories.status = "published"', 'left')
                      ->where('categories.parent_id', $parentId)
                      ->groupBy('categories.id')
                      ->orderBy('name', 'ASC');

        return $builder->get()->getResultArray();
    }
}
