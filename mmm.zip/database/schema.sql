-- database/schema.sql

-- Users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    avatar VARCHAR(255),
    bio TEXT,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Novels table
CREATE TABLE novels (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) NOT NULL UNIQUE,
    description TEXT,
    cover_image VARCHAR(255),
    author_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    views INTEGER DEFAULT 0,
    rating DECIMAL(3,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    type VARCHAR(50), -- Added type field (Light Novel, Web Novel, etc)
    country VARCHAR(50), -- Added country field
    year INTEGER, -- Added year field
    is_featured BOOLEAN DEFAULT FALSE, -- Featured flag
    is_hot BOOLEAN DEFAULT FALSE, -- Hot flag
    is_completed BOOLEAN DEFAULT FALSE -- Completed flag
);

-- Categories table
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    parent_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Novel categories relationship
CREATE TABLE novel_categories (
    novel_id INTEGER REFERENCES novels(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    PRIMARY KEY (novel_id, category_id)
);

-- Chapters table
CREATE TABLE chapters (
    id SERIAL PRIMARY KEY,
    novel_id INTEGER REFERENCES novels(id) ON DELETE CASCADE,
    chapter_number INTEGER NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    views INTEGER DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (novel_id, chapter_number)
);

-- Bookmarks table
CREATE TABLE bookmarks (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    novel_id INTEGER REFERENCES novels(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, novel_id)
);

-- Reading progress table
CREATE TABLE reading_progress (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    novel_id INTEGER REFERENCES novels(id) ON DELETE CASCADE,
    chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
    last_read TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, novel_id)
);

-- Ratings table
CREATE TABLE ratings (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    novel_id INTEGER REFERENCES novels(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, novel_id)
);

-- Comments table
CREATE TABLE comments (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    novel_id INTEGER REFERENCES novels(id) ON DELETE CASCADE,
    chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User activities table
CREATE TABLE activities (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    action VARCHAR(100) NOT NULL,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_novels_slug ON novels(slug);
CREATE INDEX idx_novels_author ON novels(author_id);
CREATE INDEX idx_chapters_novel ON chapters(novel_id);
CREATE INDEX idx_categories_slug ON categories(slug);
CREATE INDEX idx_reading_progress_user ON reading_progress(user_id);
CREATE INDEX idx_comments_novel ON comments(novel_id);
CREATE INDEX idx_comments_chapter ON comments(chapter_id);
CREATE INDEX idx_activities_user ON activities(user_id);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_novels_updated_at
    BEFORE UPDATE ON novels
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_chapters_updated_at
    BEFORE UPDATE ON chapters
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Insert default admin user (password: admin123)
INSERT INTO users (username, email, password, role, status)
VALUES ('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active');

-- Insert some default categories
INSERT INTO categories (name, slug, description)
VALUES
    ('Tiên Hiệp', 'tien-hiep', 'Truyện tiên hiệp'),
    ('Kiếm Hiệp', 'kiem-hiep', 'Truyện kiếm hiệp'),
    ('Ngôn Tình', 'ngon-tinh', 'Truyện ngôn tình'),
    ('Đô Thị', 'do-thi', 'Truyện đô thị'),
    ('Huyền Huyễn', 'huyen-huyen', 'Truyện huyền huyễn'),
    ('Khoa Huyễn', 'khoa-huyen', 'Truyện khoa huyễn'),
    ('Võng Du', 'vong-du', 'Truyện võng du'),
    ('Dị Giới', 'di-gioi', 'Truyện dị giới'),
    ('Huyền Ảo', 'huyen-ao', 'Truyện huyền ảo'),
    ('Tâm Lý', 'tam-ly', 'Truyện tâm lý'),
    ('Lãng Mạn', 'lang-man', 'Truyện lãng mạn'),
    ('Học Đường', 'hoc-duong', 'Truyện học đường'),
    ('Trinh Thám', 'trinh-tham', 'Truyện trinh thám');
