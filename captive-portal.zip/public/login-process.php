<?php

include '../intercept.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Phương thức không hợp lệ'
    ]);
    exit;
}

$userType = $_POST['userType'] ?? '';
$password = $_POST['password'] ?? '';
$userIp = getenv('USER_IP');
$userMac = getenv('USER_MAC');

if ($userType === 'guest') {
	shell_exec("ipset add authed_guests $userIp timeout 7200");
    echo json_encode([
        'status' => 'success',
        'message' => 'Chào mừng bạn đến với mạng Wi-Fi khách. Giới hạn tốc độ 5Mbps, 120 phút kết nối.'
    ]);
    exit;
}

if ($userType === 'login') {
    $correctPassword = '88888888@';

    if ($password === $correctPassword) {
		shell_exec("ipset add authed_users $userIp");
        echo json_encode([
            'status' => 'success',
            'message' => 'Chào mừng bạn đã đăng nhập.'
        ]);
        exit;
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Sai mật khẩu. Vui lòng thử lại.'
        ]);
        exit;
    }
}

echo json_encode([
    'status' => 'error',
    'message' => 'Dữ liệu gửi lên không hợp lệ.'
]);
