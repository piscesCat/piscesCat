<?php
include '../intercept.php';

header('Content-Type: text/html');

$user_ip = $_SERVER['REMOTE_ADDR'];
$user_mac = getMacFromIp($user_ip);

$content = file_get_contents('index.html');
$content = str_replace('[USER_MAC]', htmlspecialchars($user_mac), $content);
$content = str_replace('[USER_IP]', htmlspecialchars($user_ip), $content);

echo $content;

function getMacFromIp($ip) {
    $arp_table = shell_exec("arp -n");
    $lines = explode("\n", $arp_table);

    foreach ($lines as $line) {
        if (strpos($line, $ip) !== false) {
            if (preg_match('/..:..:..:..:..:../', $line, $matches)) {
                return $matches[0];
            }
        }
    }
    return 'Không tìm thấy';
}
